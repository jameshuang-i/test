// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "SuperConfig.h"

#include "MainFrm.h"

#include "RFListDlg.h"
#include "ConnectDlg.h"
#include "KeyWordListDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_NOTIFY(TBN_DROPDOWN, AFX_IDW_TOOLBAR, OnToolbarDropDown)
	ON_COMMAND(ID_FILE_OPEN_SERVER, OnFileOpenServer)
	ON_NOTIFY(NM_CLICK, TABBAR_ID, OnTabBarClick)
	ON_NOTIFY(NM_DBLCLK, TABBAR_ID, OnTabBarDBClick)
	ON_NOTIFY(NM_RCLICK, TABBAR_ID, OnTabBarRClick)
	ON_COMMAND(ID_CONFIG_SERVERFILE, OnConfigServerfile)
	ON_COMMAND(ID_FILE_SAVE_ALL, OnFileSaveAll)
	ON_COMMAND(ID_FILE_CLOSE_ALL, OnFileCloseAll)
	ON_COMMAND(ID_CONFIG_HIGHTLIGHT, OnConfigHightlight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

static TCHAR *szCmdTexts[] =
{
	_T(""),
		_T("��"),
		_T("����"),
		_T(""),
		_T(""),
		_T(""),
		_T(""),
		_T(""),
		_T(""),
		_T(""),
		_T(""),//����
		_T(""),
		_T(""),
		_T(""),
		_T(""),
		_T("����"),
		_T("�滻"),
		_T(""),
		_T(""),
		_T("����"),
		_T(""),
		_T(""),
		_T(""),
		_T(""),
		_T(""),
		_T("����")
};

static UINT arCmdIDs[] =
{
	ID_FILE_NEW,
		ID_FILE_OPEN_SERVER,
		ID_SEPARATOR,
		ID_FILE_SAVE,
		ID_FILE_SAVE_ALL,
		ID_FILE_SAVE_AS,
		ID_SEPARATOR,
		ID_FILE_CLOSE,
		ID_FILE_CLOSE_ALL,
		ID_SEPARATOR,
		ID_EDIT_UNDO,
		ID_EDIT_CUT,
		ID_EDIT_COPY,
		ID_EDIT_PASTE,
		ID_SEPARATOR,
		ID_EDIT_FIND,
		ID_EDIT_REPLACE,
		ID_SEPARATOR,
		ID_TOOL_FRESH,
		ID_TOOL_RESTART,
		ID_TOOL_FORMAT,
		ID_SEPARATOR,
		ID_CONFIG_SERVERFILE,
		ID_CONFIG_HIGHTLIGHT,
		ID_SEPARATOR,
		ID_APP_ABOUT
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_LIST|TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;    
	}
	CImageList img;
	CBitmap bmp;
	bmp.LoadBitmap(IDB_TOOLBAR);
	img.Create(16,16,ILC_COLOR24,19,19);
	img.Add(&bmp,(CBitmap*)NULL);
	m_wndToolBar.GetToolBarCtrl().SetImageList(&img);
	img.Detach();
	bmp.DeleteObject();
	bmp.LoadBitmap(IDB_TOOLBAR_DISABLE);
	img.Create(16,16,ILC_COLOR24,19,19);
	img.Add(&bmp,(CBitmap*)NULL);
	m_wndToolBar.GetToolBarCtrl().SetDisabledImageList(&img);
	img.Detach();
	bmp.DeleteObject();
	
	m_wndToolBar.GetToolBarCtrl().SetExtendedStyle(TBSTYLE_EX_DRAWDDARROWS);
	
	TBBUTTON button[26]; 	
	memset(&button[0], 0, sizeof(TBBUTTON)*26);
	int nImage=0;
	for (int i=0; i<26; i++ )
	{
		button[i].iString = -1;
		button[i].fsState = TBSTATE_ENABLED;
		button[i].idCommand=arCmdIDs[i];
		switch(arCmdIDs[i])
		{
		case ID_FILE_OPEN_SERVER:
		case ID_FILE_SAVE_AS:
			button[i].fsStyle=TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE|TBBS_DROPDOWN;
			button[i].iBitmap = nImage++;
			break;
		case ID_SEPARATOR:
			button[i].fsStyle = TBSTYLE_SEP;
			break;
		default:
			button[i].fsStyle=TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE;
			button[i].iBitmap = nImage++;
		}
	}
	m_wndToolBar.GetToolBarCtrl().AddButtons(26,&button[0]);
	for(i=0;i<26;i++)
		m_wndToolBar.SetButtonText(i, szCmdTexts[i]);
	if (!m_wndTabBar.Create(this))
	{
		TRACE0("Failed to create tabbar\n");
		return -1;      // fail to create
	}
	/*
	if (!m_wndStatusBar.Create(this) ||!m_wndStatusBar.SetIndicators(indicators,sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	*/
	//m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |CBRS_TOOLTIPS | CBRS_FLYBY);

	return 0;
}

void CMainFrame::OnToolbarDropDown(NMHDR* pNotifyStruct, LRESULT *plr)
{
	NMTOOLBAR* pNMToolBar = (NMTOOLBAR*)pNotifyStruct;
	CRect rect;
	CMenu* pPopup,menu;
	
	m_wndToolBar.GetToolBarCtrl().GetRect(pNMToolBar->iItem, &rect);
	rect.top = rect.bottom;
	::ClientToScreen(pNMToolBar->hdr.hwndFrom, &rect.TopLeft());
	
	switch (pNMToolBar->iItem)
	{
	case ID_FILE_OPEN_SERVER:
		menu.LoadMenu(IDR_MAINFRAME);
		pPopup =menu.GetSubMenu(0)->GetSubMenu(1);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, rect.left, rect.top + 1, AfxGetMainWnd());
		break;
	case ID_FILE_SAVE_AS:
		menu.LoadMenu(IDR_CONFIGTYPE);
		pPopup =menu.GetSubMenu(0)->GetSubMenu(5);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, rect.left, rect.top + 1, AfxGetMainWnd());
		break;
	}
	
	*plr = TBDDRET_DEFAULT;
    
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnFileOpenServer() 
{
	CConnectDlg dlg;
	
	dlg.DoModal();
}


void CMainFrame::OnTabBarClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CTABBAR_NMHDR* pItem=(CTABBAR_NMHDR*)pNMHDR;
	DWORD dwData=pItem->lpExtra;
	MDIActivate(((CWnd*)dwData));
	*pResult=0;
}

void CMainFrame::OnTabBarRClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CMenu popmenu;
	CPoint ptScreen;
	GetCursorPos(&ptScreen);
	ScreenToClient(&ptScreen);
	
	popmenu.CreatePopupMenu();
	popmenu.AppendMenu(0, ID_FILE_SAVE, "����(&S)");
	popmenu.AppendMenu(0, ID_FILE_SAVE_ALL, "��������(&A)");
	popmenu.AppendMenu(0, MF_SEPARATOR);
	popmenu.AppendMenu(0, ID_FILE_CLOSE, "�ر�(&C)");
	popmenu.AppendMenu(0, ID_FILE_CLOSE_ALL, "�ر�����(&A)");
	popmenu.AppendMenu(0, MF_SEPARATOR);
	popmenu.AppendMenu(0, ID_TOOL_FRESH, "ˢ��(&R)");
	popmenu.AppendMenu(0, ID_TOOL_FORMAT, "��ʾ��ʽ��(&F)");
	
	ClientToScreen (&ptScreen);
	popmenu.TrackPopupMenu(TPM_RIGHTBUTTON, ptScreen.x, ptScreen.y, this);
	popmenu.DestroyMenu();
	
	*pResult=0;
}

void CMainFrame::OnTabBarDBClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CTABBAR_NMHDR* pItem=(CTABBAR_NMHDR*)pNMHDR;
	CWnd* pWnd=(CWnd*)pItem->lpExtra;
	pWnd->SendMessage(WM_CLOSE,0,0);
	*pResult=0;
}

void CMainFrame::OnConfigServerfile() 
{
	CRFListDlg dlg;
	dlg.DoModal();
}

void CMainFrame::OnFileSaveAll() 
{
	POSITION pos=theApp.GetFirstDocTemplatePosition();
	if(pos!=NULL)
	{
		CDocTemplate* pDocTemplate=theApp.GetNextDocTemplate(pos);
		if(pDocTemplate!=NULL)
		{
			pos=pDocTemplate->GetFirstDocPosition();
			while(pos!=NULL)
			{
				CDocument* pDoc=pDocTemplate->GetNextDoc(pos);
				POSITION posV=pDoc->GetFirstViewPosition();
				if(posV!=NULL)
				{
					CView* pView=pDoc->GetNextView(posV);
					CString sText;
					pView->GetWindowText(sText);
					if(sText.Left(6)!="����")
						pDoc->DoFileSave();
				}

			}
			
		}
	}
}

void CMainFrame::OnFileCloseAll() 
{
	POSITION pos=theApp.GetFirstDocTemplatePosition();
	if(pos!=NULL)
	{
		CDocTemplate* pDocTemplate=theApp.GetNextDocTemplate(pos);
		if(pDocTemplate!=NULL)
		{
			pos=pDocTemplate->GetFirstDocPosition();
			while(pos!=NULL)
			{
				CDocument* pDoc=pDocTemplate->GetNextDoc(pos);
				POSITION posV=pDoc->GetFirstViewPosition();
				if(posV!=NULL)
				{
					CView* pView=pDoc->GetNextView(posV);
					pView->GetParent()->PostMessage(WM_CLOSE);
				}
			}
		}
	}
}

void CMainFrame::OnConfigHightlight() 
{
	CKeyWordListDlg dlg;
	dlg.DoModal();
}
