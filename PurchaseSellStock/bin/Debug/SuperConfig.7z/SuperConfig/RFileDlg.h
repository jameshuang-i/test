#if !defined(AFX_RFILEDLG_H__27D660FF_F4CF_4A7A_AFC3_C3F2ED065234__INCLUDED_)
#define AFX_RFILEDLG_H__27D660FF_F4CF_4A7A_AFC3_C3F2ED065234__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RFileDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRFileDlg dialog

class CRFileDlg : public CDialog
{
// Construction
public:
	CString m_sName;
	int m_nOperatType;
	CRFileDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRFileDlg)
	enum { IDD = IDD_RFILEBOX };
	BOOL	m_bEnCode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRFileDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRFileDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RFILEDLG_H__27D660FF_F4CF_4A7A_AFC3_C3F2ED065234__INCLUDED_)
