// KeyWordListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "superconfig.h"
#include "KeyWordListDlg.h"

#include "KeyWordDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeyWordListDlg dialog


CKeyWordListDlg::CKeyWordListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeyWordListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeyWordListDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CKeyWordListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeyWordListDlg)
	DDX_Control(pDX, IDC_LST_KEYWORDS, m_ctrList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKeyWordListDlg, CDialog)
	//{{AFX_MSG_MAP(CKeyWordListDlg)
	ON_BN_CLICKED(ID_ADD, OnAdd)
	ON_BN_CLICKED(ID_DEL, OnDel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeyWordListDlg message handlers

BOOL CKeyWordListDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	DWORD dwStyle = m_ctrList.GetExtendedStyle(); //��ȡ��ǰ��չ��ʽ
	dwStyle |= LVS_EX_FULLROWSELECT; //ѡ��ĳ��ʹ���и�����report���ʱ��
	dwStyle |= LVS_EX_GRIDLINES; //�����ߣ�report���ʱ��
	m_ctrList.SetExtendedStyle(dwStyle); //������չ���
	
	
	m_ctrList.InsertColumn(1,"��������",LVCFMT_LEFT,200);
	m_ctrList.InsertColumn(2,"�ļ�����",LVCFMT_LEFT,100);
	m_ctrList.InsertColumn(3,"��������",LVCFMT_CENTER,100);
	
	ReLoadList();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CKeyWordListDlg::ReLoadList()
{
	m_ctrList.DeleteAllItems();
	
	int nCount=theApp.GetKeyWordCount();
	for(int i=1;i<=nCount;i++)
	{
		int nRow=m_ctrList.InsertItem(i-1,theApp.GetKeyWordValue(i));
		m_ctrList.SetItemText(nRow,1,theApp.GetKeyWordFileName(i));
		m_ctrList.SetItemText(nRow,2,theApp.GetKeyWordSectionName(i));
	}
}

void CKeyWordListDlg::OnAdd() 
{
	CKeyWordDlg dlg;
	dlg.DoModal();
	ReLoadList();
}

void CKeyWordListDlg::OnDel() 
{
	POSITION pos;
	int nIndex;
	
	pos=m_ctrList.GetFirstSelectedItemPosition();
	while(pos)
	{
		nIndex = m_ctrList.GetNextSelectedItem(pos);
		theApp.DelKeyWord(m_ctrList.GetItemText(nIndex,1),m_ctrList.GetItemText(nIndex,2),m_ctrList.GetItemText(nIndex,0));
	}
	ReLoadList();
	
}
