// ftp.cpp: implementation of the ftp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SuperConfig.h"
#include "ftp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

TCHAR g_lpszFTPErrMsg[1024];
CFtpConnection *g_pConnect=NULL;
CInternetSession g_InternetSession(_T("SuperConfig/2.0"));

BOOL FtpConnect(CString sIP,CString sUsr,CString sPwd,int nPort)
{	
	memset(g_lpszFTPErrMsg,0,1024);
	try
    {
        g_pConnect = g_InternetSession.GetFtpConnection(sIP,sUsr,sPwd,nPort);
    }
    catch (CException* pEx)
    {
        pEx->GetErrorMessage(g_lpszFTPErrMsg, 1024);
        pEx->Delete();
	}
	
    if (g_pConnect != NULL) 
		return TRUE;
	else
		return FALSE;
}

void FTPClose()
{
	if(g_pConnect!=NULL)
	{
		g_pConnect->Close();
		delete g_pConnect;
	}
}

CString FTPDownLoad(CString sRemotePath,CString sLocalPath)
{
	CString sRet;
	
	memset(g_lpszFTPErrMsg,0,1024);
	sRet.Empty();
	
	try
    {
		TRACE("\n%s\n",sRemotePath);
		CFtpFileFind  finder(g_pConnect);
		if(finder.FindFile(sRemotePath))
		{   
			if(g_pConnect->GetFile(sRemotePath,sLocalPath,FALSE,FILE_ATTRIBUTE_NORMAL,FTP_TRANSFER_TYPE_ASCII))
			{
				finder.FindNextFile();   
				CTime   time;
				finder.GetLastWriteTime(time);
				sRet=time.Format("%Y%m%d%H%M%S");
			}
		}   
		finder.Close();
    }
    catch (CInternetException* pEx)
    {
        pEx->GetErrorMessage(g_lpszFTPErrMsg, 1024);
        pEx->Delete();
	}
	
	return sRet;
}

CString FTPDownLoad(CString sIP,CString sUsr,CString sPwd,CString sRemotePath,CString sLocalPath,int nPort)
{
	CString sRet;
	CFtpConnection *pConnect=NULL;

	memset(g_lpszFTPErrMsg,0,1024);
	sRet.Empty();

    try
    {
		pConnect = g_InternetSession.GetFtpConnection(sIP,sUsr,sPwd,nPort);
		CFtpFileFind  finder(pConnect);
		if(finder.FindFile(sRemotePath))
		{   
			if(pConnect->GetFile(sRemotePath,sLocalPath,FALSE,FILE_ATTRIBUTE_NORMAL,FTP_TRANSFER_TYPE_ASCII))
			{
				finder.FindNextFile();   
				CTime   time;
				finder.GetLastWriteTime(time);
				sRet=time.Format("%Y%m%d%H%M%S");
			}
		}   
		finder.Close();
    }
    catch (CInternetException* pEx)
    {
        pEx->GetErrorMessage(g_lpszFTPErrMsg, 1024);
        pEx->Delete();
	}

	if(pConnect!=NULL)
	{
		pConnect->Close();
		delete pConnect;
	}

	return sRet;
}

CString FTPUpLoad(CString sIP,CString sUsr,CString sPwd,CString sRemotePath,CString sLocalPath,int nPort)
{
	CString sRet;
	CFtpConnection *pConnect=NULL;

	memset(g_lpszFTPErrMsg,0,1024);
	sRet.Empty();

    try
    { 
		pConnect = g_InternetSession.GetFtpConnection(sIP,sUsr,sPwd,nPort);
		if(pConnect->PutFile(sLocalPath,sRemotePath,FTP_TRANSFER_TYPE_ASCII))
		{
			CFtpFileFind  finder(pConnect); 
			if(finder.FindFile(sRemotePath))
			{   
				finder.FindNextFile();   
				CTime   time;
				finder.GetLastWriteTime(time);
				sRet=time.Format("%Y%m%d%H%M%S");
			}
			finder.Close();
		}

    }
    catch (CInternetException* pEx)
    {
        pEx->GetErrorMessage(g_lpszFTPErrMsg, 1024);
        pEx->Delete();
	}
	
	if(pConnect!=NULL)
	{
		pConnect->Close();
		delete pConnect;
	}
	return sRet;
}

CString FTPGetTime(CString sIP,CString sUsr,CString sPwd,CString sRemotePath,int nPort)
{
	CString sRet;
	CFtpConnection *pConnect=NULL;
	
	memset(g_lpszFTPErrMsg,0,1024);
	sRet.Empty();
	
    try
    { 
		pConnect = g_InternetSession.GetFtpConnection(sIP,sUsr,sPwd,nPort);
		CFtpFileFind  finder(pConnect); 
		if(finder.FindFile(sRemotePath))
		{   
			finder.FindNextFile();   
			CTime   time;
			finder.GetLastWriteTime(time);
			sRet=time.Format("%Y%m%d%H%M%S");
		}
		finder.Close();
	}
    catch (CInternetException* pEx)
    {
        pEx->GetErrorMessage(g_lpszFTPErrMsg, 1024);
        pEx->Delete();
	}
	
	if(pConnect!=NULL)
	{
		pConnect->Close();
		delete pConnect;
	}
	return sRet;
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


