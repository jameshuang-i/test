#if !defined(AFX_RFLISTDLG_H__7C4F2324_17B5_4C5E_9533_10F69E8EF0C2__INCLUDED_)
#define AFX_RFLISTDLG_H__7C4F2324_17B5_4C5E_9533_10F69E8EF0C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RFListDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRFListDlg dialog

class CRFListDlg : public CDialog
{
// Construction
public:
	void ReLoadList();
	CRFListDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRFListDlg)
	enum { IDD = IDD_RFLISTBOX };
	CListCtrl	m_ctrRFlist;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRFListDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRFListDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	afx_msg void OnModify();
	afx_msg void OnDel();
	afx_msg void OnDblclkLstRfiles(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RFLISTDLG_H__7C4F2324_17B5_4C5E_9533_10F69E8EF0C2__INCLUDED_)
