#if !defined(AFX_SECTIONBAR_H__689D125E_085A_48C7_8172_BCEE7C3AFE32__INCLUDED_)
#define AFX_SECTIONBAR_H__689D125E_085A_48C7_8172_BCEE7C3AFE32__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SectionBar.h : header file
//
#include <Afxtempl.h>

#define SECTIONBAR_ID	1002
#define SECTIONBAR_WINDCLASSNAME	_T("SECTIONBAR.WINDOWCLASS")
#define SECTIONBAR_ITEMCLOSE	10001
#define SECTIONBAR_SCROLLINTERVAL	20
#define MAX_LABEL_TEXT	50

#define SECTIONBAR_CLICK				NM_CLICK


typedef struct _CSECTIONBAR_NMHDR 
{
    NMHDR	hdr;
	TCHAR	pszTitle[MAX_LABEL_TEXT];
} CSECTIONBAR_NMHDR;

/////////////////////////////////////////////////////////////////////////////
// CSectionBar dialog

class CSectionBar : public CControlBar
{
// Construction
public:
	CSectionBar();   // standard constructor
	virtual ~CSectionBar();
	BOOL Create(CWnd* pParentWnd,DWORD dwStyle=WS_CHILD|WS_VISIBLE|WS_VSCROLL|CBRS_LEFT|CBRS_SIZE_DYNAMIC|CBRS_GRIPPER,UINT nID = SECTIONBAR_ID);

	typedef struct 
	{
		CString		sTitle;
		CRect		rect;
	}SectionBarItem;
	
//Data
private:
	CSize	m_szFloat;
	UINT	m_nWidth;
	UINT	m_nHeight;
	UINT    m_nDockBarID;
	int		m_nHoverItemID;
	int		m_nOldHoverItemID;
	BOOL	m_bInPress;
	BOOL	m_bOldInPress;
	BOOL	m_bTracking;
	UINT	m_nHtEdg;
	int		m_nTrackPosOld;
	int		m_nTrackEdgeOfs;
	CArray <SectionBarItem*,SectionBarItem*>	m_aItems;
	int		m_nSelItemID;
	int		m_nOldSelItemID;
	BOOL	m_bNeedPaint;
	CFont	m_Font;
	
// Overrides
public:
	int SetItemSelect(CString sTitle);
	void CalcLayout();
	void RemoveAll();
	int InsertItem(CString sTitle,int nIndex=-1);
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
    virtual CSize CalcDynamicLayout(int nLength, DWORD dwMode);
	virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);
	
	BOOL IsFloating() const;
	void ShowTrackInvert();
	void UpdateTrackSize(CPoint& point);
	BOOL NotifyParent(UINT code, int nItem);

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSectionBar)
	afx_msg void OnPaint();
	afx_msg void OnNcPaint();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg UINT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECTIONBAR_H__689D125E_085A_48C7_8172_BCEE7C3AFE32__INCLUDED_)
