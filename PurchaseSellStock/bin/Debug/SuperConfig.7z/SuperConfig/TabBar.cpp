// TabBar.cpp : implementation file
//

#include "stdafx.h"
#include "SuperConfig.h"
#include "TabBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabBar CControlBar

CTabBar::CTabBar()
{
	m_nSelectItem=-1;
	m_nHoverItem=-1;
	HINSTANCE hInst = AfxGetInstanceHandle();
	m_hIconLocal=LoadIcon(hInst,MAKEINTRESOURCE(IDI_LOCAL));
	m_hIconRemote=LoadIcon(hInst,MAKEINTRESOURCE(IDI_REMOTE));
	m_hIconLocal2=LoadIcon(hInst,MAKEINTRESOURCE(IDI_LOCAL_MODFIY));
	m_hIconRemote2=LoadIcon(hInst,MAKEINTRESOURCE(IDI_REMOTE_MODFIY));
	
	LOGFONT lfSel={12, 0, 0, 0, FW_NORMAL, 0, 0, 0,DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS,DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Fixedsys"};
	m_Font.CreateFontIndirect(&lfSel);

	m_nOffsetCount=0;
	m_nWidthShow=0;
	m_rectLeftBtn.SetRect(0,4,16,20);
	m_rectRightBtn.SetRect(0,4,16,20);
	m_bTracing=FALSE;
	m_nDrgSrc=-1;
	m_hCursorMove=AfxGetApp()->LoadCursor(IDC_CURSORMOVE);

	CPoint pt[8];
	pt[0].x=-3;	pt[0].y=0;
	pt[1].x=4;	pt[1].y=0;
	pt[2].x=1;	pt[2].y=3;
	pt[3].x=1;	pt[3].y=TABBAR_HEIGHT-7;
	pt[4].x=4;	pt[4].y=TABBAR_HEIGHT-3;
	pt[5].x=-3;	pt[5].y=TABBAR_HEIGHT-3;
	pt[6].x=0;	pt[6].y=TABBAR_HEIGHT-7;
	pt[7].x=0;	pt[7].y=3;
	m_rgnInsert.CreatePolygonRgn(&pt[0],8,WINDING);	

	pt[0].x=0; pt[0].y=6;
	pt[1].x=0; pt[1].y=TABBAR_HEIGHT-6;
	pt[2].x=12;pt[2].y=TABBAR_HEIGHT/2;
	m_rgnTriangleRight.CreatePolygonRgn(&pt[0],3,ALTERNATE);

	pt[0].x=0; pt[0].y=TABBAR_HEIGHT/2;
	pt[1].x=12; pt[1].y=6;
	pt[2].x=12;pt[2].y=TABBAR_HEIGHT-6;
	m_rgnTriangleLeft.CreatePolygonRgn(&pt[0],3,ALTERNATE);

}

CTabBar::~CTabBar()
{
	int nCount=m_aItems.GetSize();
	for(int i=0; i< nCount; i++)
		delete m_aItems[i];
	m_aItems.RemoveAll();
}

BOOL CTabBar::Create(CWnd* pParentWnd, DWORD dwStyle, UINT nID)
{
	ASSERT_VALID(pParentWnd);   // must have a parent
	ASSERT (!((dwStyle & CBRS_SIZE_FIXED) && (dwStyle & CBRS_SIZE_DYNAMIC)));
	
	// save the style
	m_dwStyle = (dwStyle & CBRS_ALL);
	dwStyle &= ~CBRS_ALL;
	dwStyle |= CCS_NOPARENTALIGN|CCS_NOMOVEY|CCS_NORESIZE|CCS_NODIVIDER;

	//register windowsclass
	WNDCLASS wndcls;
    HINSTANCE hInst = AfxGetInstanceHandle();
    if (!(::GetClassInfo(hInst, TABBAR_WINDCLASSNAME, &wndcls)))
    {
        wndcls.style            = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
        wndcls.lpfnWndProc      = ::DefWindowProc;
        wndcls.cbClsExtra       = wndcls.cbWndExtra = 0;
        wndcls.hInstance        = hInst;
        wndcls.hIcon            = NULL;
        wndcls.hCursor          = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
        wndcls.hbrBackground    = (HBRUSH) (COLOR_BTNFACE+1);
        wndcls.lpszMenuName     = NULL;
        wndcls.lpszClassName    = TABBAR_WINDCLASSNAME;
        if (!AfxRegisterClass(&wndcls))
        {
            AfxThrowResourceException();
            return FALSE;
        }
    }
	// create the HWND
	CRect rect; rect.SetRectEmpty();
	if (!CWnd::Create(TABBAR_WINDCLASSNAME, NULL, dwStyle, rect, pParentWnd, nID))
		return FALSE;
	
	if(m_ctrTip.Create(this))
		m_ctrTip.Activate(TRUE);

	return TRUE;
}

CSize CTabBar::CalcFixedLayout(BOOL bStretch, BOOL bHorz)
{
	return CSize(32767,TABBAR_HEIGHT);
}

int CTabBar::InsertItem(CString sText,CString sTip,iconType nicon,DWORD lpExtra,int nIndex)
{
	int nCount=m_aItems.GetSize();
	if(nIndex==-1)
		nIndex=nCount;
	if(nIndex<0 || nIndex>nCount)
		return -1;
	TabBarItem* pItem=new TabBarItem();
	if(pItem==NULL)
		return -1;

	pItem->sTitle=sText;
	pItem->lpExtra=lpExtra;
	pItem->sTip=sTip;
	pItem->nIcon=nicon;
	CalcItemSize(pItem);
	try
	{
		m_aItems.InsertAt(nIndex,pItem);
	}
	catch (CMemoryException* e)
	{
		e->Delete();
		delete pItem;
		return -1;
	}
	if(m_nSelectItem>=nIndex && m_nSelectItem<TABBAR_LEFTEBTN)
		m_nSelectItem++;
	if(m_nHoverItem>=nIndex && m_nHoverItem<TABBAR_LEFTEBTN)
		m_nHoverItem++;
	
	CalcLayout();
	Invalidate(TRUE);
	return nIndex;
}

int CTabBar::RemoveItem(DWORD lpExtra)
{
	int nCount=m_aItems.GetSize();
	int nRet=-1;
	for(int i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->lpExtra==lpExtra)
		{
			m_aItems.RemoveAt(i);
			nRet=i;
			break;		
		}
	}
	if(nRet>=0)
	{
		if(m_nSelectItem==nRet)
			m_nSelectItem=-1;
		else if(m_nSelectItem>nRet)
			m_nSelectItem--;
		if(m_nHoverItem==nRet)
			m_nHoverItem=-1;
		else if(m_nHoverItem>nRet && m_nHoverItem<TABBAR_LEFTEBTN)
			m_nHoverItem--;
		CalcLayout();
		Invalidate(FALSE);
	}
	return nRet;
}
BOOL CTabBar::SetSelected(DWORD lpExtra)
{
	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->lpExtra==lpExtra)
		{
			m_nSelectItem=i;
			break;		
		}
	}
	Invalidate(FALSE);
	return TRUE;
}

void CTabBar::CalcItemSize(TabBarItem* pItem)
{
	CDC *pDC=GetDC();
	CRect rcText;
	CFont* pFontOld=pDC->SelectObject(&m_Font);
	int nret = pDC->DrawText(pItem->sTitle, rcText, DT_CALCRECT);
	if(nret>0)
	{
		if(pItem->nIcon==iconNone)
			pItem->rect.right=pItem->rect.left+rcText.Width()+8;
		else
			pItem->rect.right=pItem->rect.left+rcText.Width()+TABBAR_ICONHEIGHT+12;
	}
	pItem->rect.top=1;
	pItem->rect.bottom=TABBAR_HEIGHT-4;
	pDC->SelectObject(pFontOld);
	ReleaseDC(pDC);

	CRgn rgnBk1,rgnBk2;
	rgnBk1.CreateRoundRectRgn(pItem->rect.left,pItem->rect.top,pItem->rect.right,pItem->rect.bottom+2,5,5);
	rgnBk2.CreateRectRgn(pItem->rect.left,pItem->rect.top+10,pItem->rect.right-1,pItem->rect.bottom+2);
	pItem->rgn.CombineRgn(&rgnBk1,&rgnBk2,RGN_OR);
}

void  CTabBar::CalcLayout()
{
	int nCount=m_aItems.GetSize();
	int nOffset=0,i;

	int nTipCount=m_ctrTip.GetToolCount();
	for(i=1;i<=nTipCount;i++)
		m_ctrTip.DelTool(this,i+1);

	for(i=0;i<m_nOffsetCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		nOffset-=pItem->rect.Width();
	}
	for(i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);	
		pItem->rgn.OffsetRgn(nOffset-pItem->rect.left,0);
		pItem->rect.OffsetRect(nOffset-pItem->rect.left,0);
		nOffset+=pItem->rect.Width();
		m_ctrTip.AddTool(this,pItem->sTip,pItem->rect,i+1);
	}
	m_nWidthShow=nOffset;
}

int	 CTabBar::HitTest(CPoint pt)
{
	if(m_rectLeftBtn.PtInRect(pt))
		return TABBAR_LEFTEBTN;
	if(m_rectRightBtn.PtInRect(pt))
		return TABBAR_RIGHTBTN;

	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->rect.PtInRect(pt))
			return i;
	}

	return -1;
}

BOOL CTabBar::NotifyParent(UINT code, int nItem)
{
	CTABBAR_NMHDR nmh;
	memset(&nmh,0,sizeof(CTABBAR_NMHDR));
	nmh.hdr.hwndFrom = GetSafeHwnd();
	nmh.hdr.idFrom = GetDlgCtrlID();
	nmh.hdr.code=code;
	TabBarItem* pItem=m_aItems.GetAt(nItem);
	nmh.lpExtra=pItem->lpExtra;
	
	return (BOOL)GetParent()->SendMessage(WM_NOTIFY,GetDlgCtrlID(),(LPARAM)&nmh);
}

BEGIN_MESSAGE_MAP(CTabBar, CControlBar)
	//{{AFX_MSG_MAP(CTabBar)
	ON_WM_LBUTTONUP()
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_MESSAGE(WM_MOUSELEAVE,OnMouseLeave)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_RBUTTONDOWN()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabBar message handlers

void CTabBar::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	dc.SetBkMode(TRANSPARENT);
	
	CFont* pFontOld=dc.SelectObject(&m_Font);
	
	CRect rectClient;
	GetClientRect(&rectClient);
	dc.FillSolidRect(&rectClient,GetSysColor(COLOR_BTNFACE));
	
	CRect rectBottom=rectClient;
	rectBottom.top=rectBottom.bottom-3;
	dc.FillSolidRect(&rectBottom,GetSysColor(COLOR_WINDOW));
	
	dc.MoveTo(0,rectBottom.top);
	dc.LineTo(rectBottom.Width(),rectBottom.top);
	
	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->rect.left>rectClient.right-40)
			break;
		if(m_nSelectItem==i)
		{
			FillRgn(dc.m_hDC,(HRGN)pItem->rgn.m_hObject,(HBRUSH)GetStockObject(WHITE_BRUSH));
			FrameRgn(dc.m_hDC,(HRGN)pItem->rgn.m_hObject,(HBRUSH)GetStockObject(BLACK_BRUSH),1,1);
			CGdiObject* pPenOld=dc.SelectStockObject(WHITE_PEN);			
			dc.MoveTo(pItem->rect.left+1,pItem->rect.bottom+1);
			dc.LineTo(pItem->rect.right-2,pItem->rect.bottom+1);
			dc.SelectObject(pPenOld);
		}
		else if(i>0 && i!=m_nSelectItem+1)
		{
			dc.MoveTo(pItem->rect.left,pItem->rect.top+4);
			dc.LineTo(pItem->rect.left,pItem->rect.bottom-1);
		}
		CRect rectText=pItem->rect;
		rectText.OffsetRect(4,4);
		if(pItem->nIcon!=iconNone)
		{
			switch(pItem->nIcon)
			{
			case iconLocal:
				DrawIconEx(dc.m_hDC,pItem->rect.left+4,4,m_hIconLocal,TABBAR_ICONHEIGHT,TABBAR_ICONHEIGHT,0,NULL,DI_NORMAL);	
				break;
			case iconLocal2:
				DrawIconEx(dc.m_hDC,pItem->rect.left+4,4,m_hIconLocal2,TABBAR_ICONHEIGHT,TABBAR_ICONHEIGHT,0,NULL,DI_NORMAL);
				break;
			case iconRemote:
				DrawIconEx(dc.m_hDC,pItem->rect.left+4,4,m_hIconRemote,TABBAR_ICONHEIGHT,TABBAR_ICONHEIGHT,0,NULL,DI_NORMAL);
				break;
			case iconRemote2:
				DrawIconEx(dc.m_hDC,pItem->rect.left+4,4,m_hIconRemote2,TABBAR_ICONHEIGHT,TABBAR_ICONHEIGHT,0,NULL,DI_NORMAL);
				break;
			}
			rectText.OffsetRect(TABBAR_ICONHEIGHT+2,0);	
		}
		if(m_nHoverItem==i)
		{
			if(m_nDrgSrc>=0 && m_nDrgSrc<TABBAR_LEFTEBTN && m_nDrgSrc!=m_nHoverItem)
			{
				m_rgnInsert.OffsetRgn(pItem->rect.left,0);
				FillRgn(dc.m_hDC,(HRGN)m_rgnInsert.m_hObject,(HBRUSH)GetStockObject(BLACK_BRUSH));
				m_rgnInsert.OffsetRgn(-pItem->rect.left,0);
			}
			rectText.OffsetRect(0,-1);
		}
		dc.TextOut(rectText.left,rectText.top,pItem->sTitle);
	}

	CRect rectRight=rectClient;
	rectRight.left=rectRight.right-40;
	rectRight.bottom-=4;
	dc.FillSolidRect(&rectRight,GetSysColor(COLOR_BTNFACE));

	m_rectRightBtn.OffsetRect(rectClient.right-20-m_rectRightBtn.left,0);
	m_rectLeftBtn.OffsetRect(rectClient.right-40-m_rectLeftBtn.left,0);

	if(m_nHoverItem==TABBAR_RIGHTBTN && m_nWidthShow>rectClient.Width()-40)
	{
		dc.FillSolidRect(&m_rectRightBtn,RGB(182,189,210));
		FrameRect(dc.m_hDC,&m_rectRightBtn,(HBRUSH)GetStockObject(BLACK_BRUSH));
	}
	if(m_nHoverItem==TABBAR_LEFTEBTN && m_nOffsetCount>0)
	{
		dc.FillSolidRect(&m_rectLeftBtn,RGB(182,189,210));
		FrameRect(dc.m_hDC,&m_rectLeftBtn,(HBRUSH)GetStockObject(BLACK_BRUSH));
	}

	m_rgnTriangleLeft.OffsetRgn(m_rectLeftBtn.left+2,0);
	m_rgnTriangleRight.OffsetRgn(m_rectRightBtn.left+2,0);	
	if(m_nWidthShow>rectClient.Width()-40)
		FillRgn(dc.m_hDC,(HRGN)m_rgnTriangleRight,(HBRUSH)GetStockObject(BLACK_BRUSH));
	else
		FillRgn(dc.m_hDC,(HRGN)m_rgnTriangleRight,(HBRUSH)GetStockObject(GRAY_BRUSH));
	if(m_nOffsetCount>0)
		FillRgn(dc.m_hDC,(HRGN)m_rgnTriangleLeft,(HBRUSH)GetStockObject(BLACK_BRUSH));
	else
		FillRgn(dc.m_hDC,(HRGN)m_rgnTriangleLeft,(HBRUSH)GetStockObject(GRAY_BRUSH));
	m_rgnTriangleLeft.OffsetRgn(-m_rectLeftBtn.left-2,0);
	m_rgnTriangleRight.OffsetRgn(-m_rectRightBtn.left-2,0);

	dc.SelectObject(pFontOld);
}

void CTabBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	CControlBar::OnMouseMove(nFlags, point);
	
	if(!m_bTracing)
	{
		TRACKMOUSEEVENT trackmouseevent;
		trackmouseevent.cbSize = sizeof(trackmouseevent);
		trackmouseevent.dwFlags = TME_LEAVE;
		trackmouseevent.hwndTrack = GetSafeHwnd();
		trackmouseevent.dwHoverTime = 0;
		_TrackMouseEvent(&trackmouseevent);
		m_bTracing=TRUE;
	}
	
	int nHit=HitTest(point);
	if(nHit!=m_nHoverItem)
	{
		m_nHoverItem=nHit;
		Invalidate(FALSE);
	}
}

LONG CTabBar::OnMouseLeave(WPARAM /*wParam*/, LPARAM /*lParam*/) 
{
	m_bTracing=FALSE;
	m_nDrgSrc=-1;
	if(m_nHoverItem!=-1)
	{
		m_nHoverItem=-1;
		Invalidate(FALSE);
	}
	return 0;

}

void CTabBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CControlBar::OnLButtonDown(nFlags, point);	
	//SetCapture();

	int nHit=HitTest(point);
	if(nHit>=0)
		m_nDrgSrc=nHit;
	else
		return;

	if(nHit==TABBAR_RIGHTBTN || nHit==TABBAR_LEFTEBTN)
		return;

	SetTimer(TABBAR_TIMER_DRAG,300,NULL);

}


void CTabBar::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CControlBar::OnLButtonUp(nFlags, point);
	//ReleaseCapture();

	int nHit=HitTest(point);
	
	if(nHit==TABBAR_RIGHTBTN)
	{
		CRect rclient;
		GetClientRect(&rclient);
		if(m_nWidthShow>rclient.Width()-40)
		{
			m_nOffsetCount++;
			CalcLayout();
			Invalidate(FALSE);
		}
		return;
	}
	if(nHit==TABBAR_LEFTEBTN)
	{
		if(m_nOffsetCount>0)
		{
			m_nOffsetCount--;
			CalcLayout();
			Invalidate(FALSE);
		}
		return;
	}

	if(m_nDrgSrc>=0)
	{
		if(nHit==m_nDrgSrc)
			NotifyParent(TABBAR_CLICK,nHit);
		else
		{
			TabBarItem* pItem=m_aItems.GetAt(m_nDrgSrc);
			int nDrgDst=nHit;

			if(nDrgDst==-1)
				nDrgDst=m_aItems.GetSize();

			m_aItems.RemoveAt(m_nDrgSrc);
			if(nDrgDst>m_nDrgSrc)
				m_aItems.InsertAt(--nDrgDst,pItem);
			else
				m_aItems.InsertAt(nDrgDst,pItem);
			
			if(m_nSelectItem==m_nDrgSrc)
				m_nSelectItem=nDrgDst;
			else if (m_nSelectItem>=nDrgDst && m_nSelectItem<m_nDrgSrc)
				m_nSelectItem++;
			else if (m_nSelectItem>m_nDrgSrc && m_nSelectItem<=nDrgDst)
				m_nSelectItem--;
	
	
			CalcLayout();
			Invalidate();
		}
		m_nDrgSrc=-1;
	}

}

void CTabBar::OnLButtonDblClk(UINT nFlags, CPoint point) 
{	
	CControlBar::OnLButtonDblClk(nFlags, point);

	int nHit=HitTest(point);
	if(nHit<0)
		return;
	
	if(nHit==TABBAR_RIGHTBTN)
	{
		CRect rclient;
		GetClientRect(&rclient);
		if(m_nWidthShow>rclient.Width()-40)
		{
			m_nOffsetCount++;
			CalcLayout();
			Invalidate(FALSE);
		}
		return;
	}
	if(nHit==TABBAR_LEFTEBTN)
	{
		if(m_nOffsetCount>0)
		{
			m_nOffsetCount--;
			CalcLayout();
			Invalidate(FALSE);
		}
		return;
	}
	
	NotifyParent(TABBAR_DBLCLK,nHit);
	
	m_nDrgSrc=-1;

}


void CTabBar::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CControlBar::OnRButtonDown(nFlags, point);
	
	int nHit=HitTest(point);
	if(nHit<0)
		return;
	
	if(nHit==TABBAR_RIGHTBTN || nHit==TABBAR_LEFTEBTN)
		return;
	
	NotifyParent(TABBAR_RCLICK,nHit);
	
	m_nDrgSrc=-1;
}

BOOL CTabBar::PreTranslateMessage(MSG* pMsg) 
{
	if(m_ctrTip.m_hWnd && (pMsg->message==WM_LBUTTONDOWN || pMsg->message==WM_LBUTTONUP || pMsg->message==WM_MOUSEMOVE))
		m_ctrTip.RelayEvent(pMsg);
	
	return CControlBar::PreTranslateMessage(pMsg);
}


void CTabBar::OnTimer(UINT nIDEvent) 
{	
	CControlBar::OnTimer(nIDEvent);

	if(nIDEvent==TABBAR_TIMER_DRAG)
	{
		KillTimer(TABBAR_TIMER_DRAG);
		if(m_nDrgSrc>=0)
		{
			SetTimer(TABBAR_TIMER_DRAG,10,NULL);
			SetCursor(m_hCursorMove);
		}
	}
}

void CTabBar::SetShowIcon(DWORD lpExtra,iconType iconT)
{
	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->lpExtra==lpExtra)
		{
			pItem->nIcon=iconT;
			break;		
		}
	}
	Invalidate(FALSE);
}

void CTabBar::SetText(DWORD lpExtra,CString sText)
{
	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->lpExtra==lpExtra)
		{
			pItem->sTitle=sText;
			CalcItemSize(pItem);
			break;		
		}
	}
	CalcLayout();
}


void CTabBar::SetTip(DWORD lpExtra,CString sTip)
{
	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		TabBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->lpExtra==lpExtra)
		{
			pItem->sTip=sTip;
			break;		
		}
	}
	Invalidate(TRUE);
}

