// RFListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SuperConfig.h"
#include "RFListDlg.h"

#include "RFileDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRFListDlg dialog


CRFListDlg::CRFListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRFListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRFListDlg)
	
	//}}AFX_DATA_INIT
}


void CRFListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRFListDlg)
	DDX_Control(pDX, IDC_LST_RFILES, m_ctrRFlist);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRFListDlg, CDialog)
	//{{AFX_MSG_MAP(CRFListDlg)
	ON_BN_CLICKED(ID_ADD, OnAdd)
	ON_BN_CLICKED(ID_MODIFY, OnModify)
	ON_BN_CLICKED(ID_DEL, OnDel)
	ON_NOTIFY(NM_DBLCLK, IDC_LST_RFILES, OnDblclkLstRfiles)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRFListDlg message handlers

BOOL CRFListDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	DWORD dwStyle = m_ctrRFlist.GetExtendedStyle(); //��ȡ��ǰ��չ��ʽ
	dwStyle |= LVS_EX_FULLROWSELECT; //ѡ��ĳ��ʹ���и�����report���ʱ��
	dwStyle |= LVS_EX_GRIDLINES; //�����ߣ�report���ʱ��
	m_ctrRFlist.SetExtendedStyle(dwStyle); //������չ���


	m_ctrRFlist.InsertColumn(1,"����",LVCFMT_LEFT,100);
	m_ctrRFlist.InsertColumn(2,"Զ��·����",LVCFMT_LEFT,300);
	m_ctrRFlist.InsertColumn(3,"����",LVCFMT_CENTER,40);
	
	ReLoadList();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRFListDlg::ReLoadList()
{
	m_ctrRFlist.DeleteAllItems();
	
	int nCount=theApp.GetRFilesCount();
	for(int i=1;i<=nCount;i++)
	{
		int nRow=m_ctrRFlist.InsertItem(i-1,theApp.GetRFilesName(i));
		m_ctrRFlist.SetItemText(nRow,1,theApp.GetRFilesPathName(i));
		m_ctrRFlist.SetItemText(nRow,2,theApp.GetRFilesEncode(i)? "��":"��");
	}
}

void CRFListDlg::OnAdd() 
{
	CRFileDlg dlg;
	dlg.m_nOperatType=0;
	dlg.DoModal();
	ReLoadList();
}

void CRFListDlg::OnModify() 
{
	POSITION pos=m_ctrRFlist.GetFirstSelectedItemPosition();
	if(pos==NULL)
		return;
	int nIndex=m_ctrRFlist.GetNextSelectedItem(pos);
	CString sName=m_ctrRFlist.GetItemText(nIndex,0);

	CRFileDlg dlg;
	dlg.m_nOperatType=1;
	dlg.m_sName=sName;
	dlg.DoModal();
	ReLoadList();
}

void CRFListDlg::OnDel() 
{
	POSITION pos;
	int nIndex;

	pos=m_ctrRFlist.GetFirstSelectedItemPosition();
	while(pos)
	{
		nIndex = m_ctrRFlist.GetNextSelectedItem(pos);
		CString sName=m_ctrRFlist.GetItemText(nIndex,0);
		theApp.DelRFiles(sName);
	}
	ReLoadList();
}

void CRFListDlg::OnDblclkLstRfiles(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnModify();
	*pResult = 0;
}
