// SuperConfig.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "SuperConfig.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "SuperConfigDoc.h"
#include "SuperConfigView.h"

#include "SuperFace.h"
#include "MultiDocTemplateEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigApp

BEGIN_MESSAGE_MAP(CSuperConfigApp, CWinApp)
	//{{AFX_MSG_MAP(CSuperConfigApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigApp construction

CSuperConfigApp::CSuperConfigApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSuperConfigApp object

CSuperConfigApp theApp;
BOOL g_bSyncHigh=TRUE;

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigApp initialization

BOOL CSuperConfigApp::InitInstance()
{
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	//if (LoadLibraryA("RICHED20.DLL") == NULL)
	//{
	//	AfxMessageBox(_T("Fail to load \"riched20.dll\"."),MB_OK | MB_ICONERROR);
	//	return FALSE;
	//} 

	char czProgName[MAX_PATH];
	int nRet= GetModuleFileName(0,czProgName,MAX_PATH);
	if(nRet>0)
	{
		czProgName[strlen(czProgName)-3] = '\0'; 
		strcat(czProgName,"ini");
		free((void*) m_pszProfileName);
		m_pszProfileName =_tcsdup(_T(czProgName));
		free((void*)m_pszRegistryKey);
		m_pszRegistryKey = NULL;
	}

	CMultiDocTemplateEx* pDocTemplate;
	pDocTemplate = new CMultiDocTemplateEx(IDR_CONFIGTYPE,RUNTIME_CLASS(CSuperConfigDoc),RUNTIME_CLASS(CChildFrame), RUNTIME_CLASS(CSuperConfigView));
	pDocTemplate->SetContainerInfo(IDR_CONFIGTYPE_CNTR_IP);
	AddDocTemplate(pDocTemplate);
	
	HookButtonWndClass();
	HookDialogWndClass();

	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;
	m_pMainWnd->DragAcceptFiles();

	EnableShellOpen();
	RegisterShellFileTypes(TRUE);
	SetRegistryValue(HKEY_CLASSES_ROOT,".ini", "","SuperConfig.Document");

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	
	if (cmdInfo.m_nShellCommand==cmdInfo.FileNew)
		cmdInfo.m_nShellCommand=cmdInfo.FileNothing;

	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();
	int nret=GetProfileInt("GENERAL","IsSyncHightLight",1);
	if(nret)
		g_bSyncHigh=TRUE;
	else
		g_bSyncHigh=FALSE;
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CSuperConfigApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

CString CSuperConfigApp::GetRFilesName(int nIndex)
{
	CString SectionName;
	SectionName.Format("LocalName_%d",nIndex);
	return GetProfileString("REMOTEFILES",SectionName);
}

int CSuperConfigApp::GetRFilesCount()
{
	return GetProfileInt("REMOTEFILES","Count",0);
}

CString CSuperConfigApp::GetRFilesPathName(CString strLocalName)
{
	CString SectionName;
	int nCount=GetProfileInt("REMOTEFILES","Count",0);
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("LocalName_%d",i);
		if(GetProfileString("REMOTEFILES",SectionName)==strLocalName)
		{
			SectionName.Format("RemoteFilePathName_%d",i);
			return GetProfileString("REMOTEFILES",SectionName);
		}
	}
	return "";
}

BOOL CSuperConfigApp::IsRFileExist(CString sName)
{
	CString SectionName;
	BOOL nRet=FALSE;

	int nCount=GetProfileInt("REMOTEFILES","Count",0);
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("LocalName_%d",i);
		if(GetProfileString("REMOTEFILES",SectionName)==sName)
		{	nRet=TRUE;
			break;
		}
	}
	return nRet;
}

CString CSuperConfigApp::GetRFilesPathName(int nIndex)
{
	CString SectionName;
	SectionName.Format("RemoteFilePathName_%d",nIndex);
	return GetProfileString("REMOTEFILES",SectionName);
}

BOOL CSuperConfigApp::GetRFilesEncode(int nIndex)
{
	CString SectionName;
	SectionName.Format("IsEnCode_%d",nIndex);
	return GetProfileInt("REMOTEFILES",SectionName,FALSE);
}

BOOL CSuperConfigApp::GetRFilesEncode(CString strLocalName)
{
	CString SectionName;
	int nCount=GetProfileInt("REMOTEFILES","Count",0);
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("LocalName_%d",i);
		if(GetProfileString("REMOTEFILES",SectionName)==strLocalName)
		{
			SectionName.Format("IsEncode_%d",i);
			return GetProfileInt("REMOTEFILES",SectionName,0);
		}
	}
	return 0;
}

BOOL CSuperConfigApp::AddOrModfiyRFiles(CString strLocalName, CString strRemotePathFileName, BOOL bEnCode)
{
	CString SectionName;
	int nCount=GetProfileInt("REMOTEFILES","Count",0);
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("LocalName_%d",i);
		if(GetProfileString("REMOTEFILES",SectionName)==strLocalName)
		{
			SectionName.Format("RemoteFilePathName_%d",i);
			WriteProfileString("REMOTEFILES",SectionName,strRemotePathFileName);
			SectionName.Format("IsEnCode_%d",i);
			WriteProfileInt("REMOTEFILES",SectionName,bEnCode);
			return TRUE;
		}
	}
	nCount++;
	SectionName.Format("LocalName_%d",nCount);
	WriteProfileString("REMOTEFILES",SectionName,strLocalName);
	SectionName.Format("RemoteFilePathName_%d",nCount);
	WriteProfileString("REMOTEFILES",SectionName,strRemotePathFileName);
	SectionName.Format("IsEnCode_%d",nCount);
	WriteProfileInt("REMOTEFILES",SectionName,bEnCode);
	WriteProfileInt("REMOTEFILES","Count",nCount);
	
	return TRUE;
}

BOOL CSuperConfigApp::DelRFiles(CString strLocalName)
{
	CString SectionName,SectionName2;
	BOOL bFinded=FALSE;
	int nCount=GetProfileInt("REMOTEFILES","Count",0);

	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("LocalName_%d",i);
		if(bFinded==FALSE&&GetProfileString("REMOTEFILES",SectionName)==strLocalName)
			bFinded=TRUE;
		if(bFinded&&i<nCount)
		{
			SectionName.Format("LocalName_%d",i);
			SectionName2.Format("LocalName_%d",i+1);
			WriteProfileString("REMOTEFILES",SectionName,GetProfileString("REMOTEFILES",SectionName2));
			SectionName.Format("RemoteFilePathName_%d",i);
			SectionName2.Format("RemoteFilePathName_%d",i+1);
			WriteProfileString("REMOTEFILES",SectionName,GetProfileString("REMOTEFILES",SectionName2));
			SectionName.Format("IsEnCode_%d",i);
			SectionName2.Format("IsEnCode_%d",i+1);
			WriteProfileInt("REMOTEFILES",SectionName,GetProfileInt("REMOTEFILES",SectionName2,FALSE));
		}
	}
	if(bFinded)
		WriteProfileInt("REMOTEFILES","Count",nCount-1);

	return bFinded;

}

void CSuperConfigApp::AddorModifyFtp(CString strIP, CString strUSR, CString strPWD)
{
	CString SectionName;
	int nCount=GetProfileInt("FTP","Count",0);

	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("IP_%d",i);
		if(GetProfileString("FTP",SectionName)==strIP)
		{
			SectionName.Format("UserName_%d",i);
			WriteProfileString("FTP",SectionName,strUSR);
			SectionName.Format("Password_%d",i);
			WriteProfileString("FTP",SectionName,strPWD);
			return;
		}
	}
	nCount++;
	WriteProfileInt("FTP","Count",nCount);
	SectionName.Format("IP_%d",i);
	WriteProfileString("FTP",SectionName,strIP);
	SectionName.Format("UserName_%d",i);
	WriteProfileString("FTP",SectionName,strUSR);
	SectionName.Format("Password_%d",i);
	WriteProfileString("FTP",SectionName,strPWD);
}

int CSuperConfigApp::GetFtpsCount()
{
	return GetProfileInt("FTP","Count",0);
}

CString CSuperConfigApp::GetFtpName(int nIndex)
{
	CString SectionName;
	SectionName.Format("IP_%d",nIndex);
	return GetProfileString("FTP",SectionName);
}

CString CSuperConfigApp::GetFtpUsr(CString strIP)
{
	CString SectionName;
	int nCount=GetProfileInt("FTP","Count",0);
	
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("IP_%d",i);
		if(GetProfileString("FTP",SectionName)==strIP)
		{
			SectionName.Format("UserName_%d",i);
			return GetProfileString("FTP",SectionName);
		}
	}
	return "";
}

CString CSuperConfigApp::GetFtpPwd(CString strIP)
{
	CString SectionName;
	int nCount=GetProfileInt("FTP","Count",0);
	
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("IP_%d",i);
		if(GetProfileString("FTP",SectionName)==strIP)
		{
			SectionName.Format("Password_%d",i);
			return GetProfileString("FTP",SectionName);
		}
	}
	return "";
}

int CSuperConfigApp::GetKeyWordCount()
{
	return GetProfileInt("KEYWORD","Count",0);
}

CString CSuperConfigApp::GetKeyWordValue(int nIndex)
{
	CString SectionName;
	SectionName.Format("Value_%d",nIndex);
	return GetProfileString("KEYWORD",SectionName);
}

CString CSuperConfigApp::GetKeyWordFileName(int nIndex)
{
	CString SectionName;
	SectionName.Format("FileName_%d",nIndex);
	return GetProfileString("KEYWORD",SectionName);
}

CString CSuperConfigApp::GetKeyWordSectionName(int nIndex)
{
	CString SectionName;
	SectionName.Format("SectionName_%d",nIndex);
	return GetProfileString("KEYWORD",SectionName);
}

void CSuperConfigApp::AddKeyWord(CString sFileName, CString sSectionName, CString sValue)
{
	CString SectionName;
	int nCount=GetProfileInt("KEYWORD","Count",0);
	
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("FileName_%d",i);
		if(GetProfileString("KEYWORD",SectionName)==sFileName)
		{
			SectionName.Format("SectionName_%d",i);
			if(GetProfileString("KEYWORD",SectionName)==sSectionName)
			{
				SectionName.Format("Value_%d",i);
				if(GetProfileString("KEYWORD",SectionName)==sValue)
					return;
			}
		}
	}
	nCount++;
	WriteProfileInt("KEYWORD","Count",nCount);
	SectionName.Format("FileName_%d",i);
	WriteProfileString("KEYWORD",SectionName,sFileName);
	SectionName.Format("SectionName_%d",i);
	WriteProfileString("KEYWORD",SectionName,sSectionName);
	SectionName.Format("Value_%d",i);
	WriteProfileString("KEYWORD",SectionName,sValue);
}

BOOL CSuperConfigApp::DelKeyWord(CString sFileName,CString sSectionName,CString sValue)
{
	CString SectionName,SectionName2;
	BOOL bFinded=FALSE;
	int nCount=GetProfileInt("KEYWORD","Count",0);
	
	for(int i=1;i<=nCount;i++)
	{
		if(bFinded==FALSE)
		{
			SectionName.Format("FileName_%d",i);
			if(GetProfileString("KEYWORD",SectionName)==sFileName)
			{
				SectionName.Format("SectionName_%d",i);
				if(GetProfileString("KEYWORD",SectionName)==sSectionName)
				{
					SectionName.Format("Value_%d",i);
					if(GetProfileString("KEYWORD",SectionName)==sValue)
						bFinded=TRUE;
				}
			}

		}

		if(bFinded&&i<nCount)
		{
			SectionName.Format("FileName_%d",i);
			SectionName2.Format("FileName_%d",i+1);
			WriteProfileString("KEYWORD",SectionName,GetProfileString("KEYWORD",SectionName2));
			SectionName.Format("SectionName_%d",i);
			SectionName2.Format("SectionName_%d",i+1);
			WriteProfileString("KEYWORD",SectionName,GetProfileString("KEYWORD",SectionName2));
			SectionName.Format("Value_%d",i);
			SectionName2.Format("Value_%d",i+1);
			WriteProfileInt("KEYWORD",SectionName,GetProfileInt("KEYWORD",SectionName2,FALSE));
		}
	}
	if(bFinded)
		WriteProfileInt("KEYWORD","Count",nCount-1);
	
	return bFinded;
	
}

BOOL CSuperConfigApp::IsKeyWordExist(CString sFileName, CString sSectionName, CString sValue)
{
	CString SectionName;
	int nCount=GetProfileInt("KEYWORD","Count",0);
	
	for(int i=1;i<=nCount;i++)
	{
		SectionName.Format("FileName_%d",i);
		if(GetProfileString("KEYWORD",SectionName).CompareNoCase(sFileName)==0)
		{
			SectionName.Format("SectionName_%d",i);
			if(GetProfileString("KEYWORD",SectionName).CompareNoCase(sSectionName)==0)
			{
				SectionName.Format("Value_%d",i);
				if(GetProfileString("KEYWORD",SectionName).CompareNoCase(sValue)==0)
					return TRUE;
			}
		}
	}
	return FALSE;
}

BOOL CSuperConfigApp::SetRegistryValue(HKEY hOpenKey,LPCTSTR szKey,LPCTSTR szValue,LPCTSTR szData)
{
	// validate input
	if( !hOpenKey || !szKey || !szKey[0] ||!szValue || !szData )
	{
		::SetLastError(E_INVALIDARG);
		return FALSE;
	}
	
	BOOL  bRetVal = FALSE;
	DWORD dwDisposition;
	DWORD dwReserved = 0;
	HKEY   hTempKey = (HKEY)0;
	
	// length specifier is in bytes, and some TCHAR
	// are more than 1 byte each
	DWORD dwBufferLength = lstrlen(szData) * sizeof(TCHAR);
	
	// Open key of interest
	// Assume all access is okay and that all keys will be stored to file
	// Utilize the default security attributes
	if( ERROR_SUCCESS == ::RegCreateKeyEx(hOpenKey, szKey, dwReserved,(LPTSTR)0, REG_OPTION_NON_VOLATILE, KEY_SET_VALUE, 0,&hTempKey, &dwDisposition))
	{	
		// dwBufferLength must include size of terminating nul
		// character when using REG_SZ with RegSetValueEx function
		dwBufferLength += sizeof(TCHAR);
		
		if( ERROR_SUCCESS == ::RegSetValueEx(hTempKey, (LPTSTR)szValue,dwReserved, REG_SZ, (LPBYTE)szData, dwBufferLength) )
		{
			bRetVal = TRUE;
		}
	}
	
	// close opened key
	if( hTempKey )
	{
		::RegCloseKey(hTempKey);
	}
	
	return bRetVal;
}

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigApp message handlers



void CSuperConfigApp::OnFileOpen() 
{
	
    CString newName;
	CString sPath;
    if (!DoPromptFileName(newName, AFX_IDS_OPENFILE,OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT, TRUE, NULL))
        return; 
    LPSTR szNames=newName.GetBuffer(newName.GetAllocLength());
	LPSTR szName=NULL;
	LPSTR szHead=NULL;
	newName.ReleaseBuffer();

    for(int i=0;i<newName.GetAllocLength();i++)
    {
        if(_T('\0')==szNames[i])
		{
            if(_T('\0')!=szNames[i+1])
			{
				szName=&szNames[i+1];
				sPath.Format("%s\\%s",szHead,szName);
				//AfxMessageBox(sPath);
				AfxGetApp()->OpenDocumentFile(szName);
			}
		}
		else if (i==0)
		{
			szHead=&szNames[i];
			//AfxGetApp()->OpenDocumentFile(szHead);
		}
    }

	if(szName==NULL && szHead!=NULL)
		AfxGetApp()->OpenDocumentFile(szHead);
}

CString CSuperConfigApp::GetTempFileName()
{
	TCHAR szTempName[MAX_PATH];
	TCHAR lpPathBuffer[MAX_PATH];
	GetTempPath(MAX_PATH,lpPathBuffer);
	::GetTempFileName(lpPathBuffer, "CFG",0,szTempName);
	CString sRet=szTempName;
	return sRet;
}
