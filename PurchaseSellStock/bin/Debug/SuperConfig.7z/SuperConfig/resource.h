//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SuperConfig.rc
//
#define IDR_CONFIGTYPE_CNTR_IP          6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_TO_CREATE            102
#define IDR_MAINFRAME                   128
#define IDR_CONFIGTYPE                  129
#define IDI_LOCAL                       130
#define IDI_LOCAL_MODFIY                131
#define IDB_DIALOG                      131
#define IDI_REMOTE                      132
#define IDB_DIALOGBOTTOM                132
#define IDI_REMOTE_MODFIY               133
#define IDB_RESTORE_NORM                133
#define IDC_CURSORMOVE                  134
#define IDB_EXIT_FOCUSE                 134
#define IDB_EXIT_NORM                   135
#define IDD_CONNECTBOX                  135
#define IDB_HELP_FOCUSE                 136
#define IDD_RFLISTBOX                   136
#define IDB_HELP_NORM                   137
#define IDD_RFILEBOX                    137
#define IDB_MAX_FOCUSE                  138
#define IDD_KEYWORDLISTBOX              138
#define IDB_MAX_NORM                    139
#define IDD_KEYWORDBOX                  139
#define IDB_MIN_FOCUSE                  140
#define IDB_MIN_MORM                    141
#define IDB_RESTORE_FOCUSE              142
#define IDB_XPBUTTONS                   143
#define IDB_TOOLBAR                     144
#define IDB_TOOLBAR_DISABLE             145
#define IDC_LST_RFILES                  1001
#define ID_ADD                          1002
#define ID_DEL                          1003
#define ID_OK                           1003
#define ID_MODIFY                       1004
#define IDC_NAME                        1004
#define IDC_PATH                        1005
#define IDC_ENCODE                      1006
#define IDC_KEYWORD                     1006
#define IDC_IP                          1007
#define IDC_USR                         1008
#define IDC_PWD                         1009
#define IDC_LST                         1010
#define ID_CONFFILELIST                 1011
#define IDC_FILE                        1011
#define IDC_SECTION                     1012
#define IDC_LST_KEYWORDS                1013
#define IDC_ALL                         1014
#define IDC_NOALL                       1015
#define IDC_RESVERSE                    1016
#define ID_CANCEL_EDIT_CNTR             32768
#define ID_FILE_OPEN_SERVER             32771
#define ID_VIEW_SYNCHIGHT               32772
#define ID_FILE_SAVE_AS_SERVER          32773
#define ID_FILE_SAVE_ALL                32774
#define ID_FILE_CLOSE_ALL               32775
#define ID_TOOL_COMMIT                  32776
#define ID_TOOL_RESTART                 32777
#define ID_TOOL_FORMAT                  32778
#define ID_TOOL_FRESH                   32779
#define ID_CONFIG_SERVERFILE            32780
#define ID_CONFIG_HIGHTLIGHT            32781
#define ID_VIEW_FORMAT_BAR              32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
