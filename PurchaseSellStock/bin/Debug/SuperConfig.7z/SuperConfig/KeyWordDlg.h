#if !defined(AFX_KEYWORDDLG_H__30246F97_68DE_45B9_9899_185E53002C18__INCLUDED_)
#define AFX_KEYWORDDLG_H__30246F97_68DE_45B9_9899_185E53002C18__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KeyWordDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CKeyWordDlg dialog

class CKeyWordDlg : public CDialog
{
// Construction
public:
	CKeyWordDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CKeyWordDlg)
	enum { IDD = IDD_KEYWORDBOX };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeyWordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CKeyWordDlg)
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYWORDDLG_H__30246F97_68DE_45B9_9899_185E53002C18__INCLUDED_)
