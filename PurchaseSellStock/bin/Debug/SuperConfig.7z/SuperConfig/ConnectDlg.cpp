// ConnectDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SuperConfig.h"
#include "ConnectDlg.h"

#include "RFListDlg.h"
#include "ftp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConnectDlg dialog


CConnectDlg::CConnectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConnectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnectDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CConnectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnectDlg)
	DDX_Control(pDX, IDC_IP, m_IPCtrl);
	DDX_Control(pDX, IDC_LST, m_FileListCtr);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnectDlg, CDialog)
	//{{AFX_MSG_MAP(CConnectDlg)
	ON_CBN_SELENDOK(IDC_IP, OnSelendokIp)
	ON_BN_CLICKED(ID_CONFFILELIST, OnConffilelist)
	ON_BN_CLICKED(IDC_ALL, OnAll)
	ON_BN_CLICKED(IDC_NOALL, OnNoall)
	ON_BN_CLICKED(IDC_RESVERSE, OnResverse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnectDlg message handlers

BOOL CConnectDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	int nCount=theApp.GetFtpsCount();
	for(int i=1;i<=nCount;i++)
		m_IPCtrl.AddString(theApp.GetFtpName(i));
	ReLoadFileList();	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CConnectDlg::OnSelendokIp() 
{
	CString sIP;
	int nIndex=m_IPCtrl.GetCurSel();
	m_IPCtrl.GetLBText(nIndex,sIP.GetBuffer(m_IPCtrl.GetLBTextLen(nIndex)));
	sIP.ReleaseBuffer();
	
	GetDlgItem(IDC_USR)->SetWindowText(theApp.GetFtpUsr(sIP));
	GetDlgItem(IDC_PWD)->SetWindowText(theApp.GetFtpPwd(sIP));
}


void CConnectDlg::OnConffilelist() 
{
	CRFListDlg dlg;
	dlg.DoModal();
	ReLoadFileList();
}

void CConnectDlg::ReLoadFileList()
{
	m_FileListCtr.ResetContent();

	int nCount=theApp.GetRFilesCount();
	for(int i=1;i<=nCount;i++)
		m_FileListCtr.AddString(theApp.GetRFilesName(i));
	for(i=0;i<nCount;i++)
		m_FileListCtr.SetCheck(i,1);
}

void CConnectDlg::OnOK() 
{
	CString sIp,sUsr,sPwd;
	CString sPathFile[100];
	int nIndex=0;
	
	GetDlgItem(IDC_IP)->GetWindowText(sIp);
	GetDlgItem(IDC_USR)->GetWindowText(sUsr);
	GetDlgItem(IDC_PWD)->GetWindowText(sPwd);
	
	CWaitCursor wait;

	if(!FtpConnect(sIp,sUsr,sPwd))
	{
		CString strErr;
		strErr.Format("�޷�����FTP��������\n\nԭ��%s",g_lpszFTPErrMsg);
		AfxMessageBox(strErr,MB_ICONERROR);
		return;	
	}
	theApp.AddorModifyFtp(sIp,sUsr,sPwd);
	
	for(int i=0;i<m_FileListCtr.GetCount();i++)
	{
		if(m_FileListCtr.GetCheck(i)==1)
		{
			CString sName,sRemotePath;
			int nLen=m_FileListCtr.GetTextLen(i);
			m_FileListCtr.GetText(i,sName.GetBuffer(nLen));
			sName.ReleaseBuffer();
			sRemotePath=theApp.GetRFilesPathName(sName);
			TRACE(sRemotePath);
			CString sLocalPath=theApp.GetTempFileName();
			TRACE(sLocalPath);
			CString sTime=FTPDownLoad(sRemotePath,sLocalPath);
			if(!sTime.IsEmpty())
				sPathFile[nIndex++].Format("C:\\FTP_SUPERCONFIG\\%s\\%s\\%s\\%s\\%s\\%s",sIp,sUsr,sPwd,sName,sTime,sLocalPath);
		}
	}
	
	FTPClose();

	for(i=0;i<nIndex;i++)
		theApp.OpenDocumentFile(sPathFile[i]);

	/*
	for(int i=0;i<m_FileListCtr.GetCount();i++)
	{
		if(m_FileListCtr.GetCheck(i)==1)
		{
			CString sName,sPathFile;
			int nLen=m_FileListCtr.GetTextLen(i);
			m_FileListCtr.GetText(i,sName.GetBuffer(nLen));
			sName.ReleaseBuffer();
			sPathFile.Format("C:\\FTP_SUPERCONFIG\\%s\\%s\\%s\\%s",sIp,sUsr,sPwd,sName);
			TRACE(sPathFile);
			theApp.OpenDocumentFile(sPathFile);
		}
	}
	*/
	CDialog::OnOK();
}

void CConnectDlg::OnAll() 
{
	for(int i=0;i<m_FileListCtr.GetCount();i++)
		m_FileListCtr.SetCheck(i,1);
}

void CConnectDlg::OnNoall() 
{
	for(int i=0;i<m_FileListCtr.GetCount();i++)
		m_FileListCtr.SetCheck(i,0);	
}

void CConnectDlg::OnResverse() 
{
	for(int i=0;i<m_FileListCtr.GetCount();i++)
		if(m_FileListCtr.GetCheck(i)==1)
			m_FileListCtr.SetCheck(i,0);
		else
			m_FileListCtr.SetCheck(i,1);
	
}
