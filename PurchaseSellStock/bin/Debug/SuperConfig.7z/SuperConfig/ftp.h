// ftp.h: interface for the ftp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FTP_H__BF62037A_70EE_469A_A4B9_B378CD518680__INCLUDED_)
#define AFX_FTP_H__BF62037A_70EE_469A_A4B9_B378CD518680__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

extern TCHAR g_lpszFTPErrMsg[1024];

BOOL FtpConnect(CString sIP,CString sUsr,CString sPwd,int nPort=21);
void FTPClose();
CString FTPDownLoad(CString sIP,CString sUsr,CString sPwd,CString sRemotePath,CString sLocalPath,int nPort=21);
CString FTPDownLoad(CString sRemotePath,CString sLocalPath);
CString FTPUpLoad(CString sIP,CString sUsr,CString sPwd,CString sRemotePath,CString sLocalPath,int nPort=21);
CString FTPGetTime(CString sIP,CString sUsr,CString sPwd,CString sRemotePath,int nPort=21);

typedef struct _FTPParam
{
	TCHAR sIP[20];
	TCHAR sUsr[20];
	TCHAR sPwd[20];
	int	nPort;
	TCHAR sServerPath[MAX_PATH];
	TCHAR sLocalPath[MAX_PATH];
	int nErrCode;
	TCHAR sErrMsg[100];
	BOOL bFinished;
}FTPParam;

#endif // !defined(AFX_FTP_H__BF62037A_70EE_469A_A4B9_B378CD518680__INCLUDED_)
