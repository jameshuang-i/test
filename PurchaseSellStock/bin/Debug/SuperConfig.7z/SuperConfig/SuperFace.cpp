// SuperFace.cpp: implementation of the SuperFace class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SuperConfig.h"
#include "SuperFace.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

WNDPROC g_lpOldDialogProcWnd=NULL;
WNDPROC g_lpOldButtonProcWnd=NULL;
DWORD	g_wMouseTrack=0;
DWORD	g_wHover=0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BOOL HookDialogWndClass()
{
	WNDCLASSEX wndcls;
    HINSTANCE hInst = NULL;//AfxGetInstanceHandle();
	wndcls.cbSize=sizeof(wndcls);
    if (!(::GetClassInfoEx(hInst, WNDCLASSNAME_DAILOG, &wndcls)))
		return FALSE;
    g_lpOldDialogProcWnd = wndcls.lpfnWndProc;
    wndcls.lpfnWndProc = ProcDialogWnd;
    if(RegisterClassEx(&wndcls)==0)
		return FALSE;
	return TRUE;
}

BOOL HookButtonWndClass()
{
	WNDCLASSEX wndcls;
    HINSTANCE hInst = NULL;//AfxGetInstanceHandle();
	wndcls.cbSize=sizeof(wndcls);
    if (!(::GetClassInfoEx(hInst, WNDCLASSNAME_BUTTON, &wndcls)))
		return FALSE;
    g_lpOldButtonProcWnd = wndcls.lpfnWndProc;
    wndcls.lpfnWndProc = ProcButtonWnd;
    if(RegisterClassEx(&wndcls)==0)
		return FALSE;
	return TRUE;
}


LRESULT CALLBACK ProcButtonWnd(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	switch(uMsg)
	{
	case BM_SETSTYLE:
		{
			//wParam &= ~SS_TYPEMASK;
			wParam |= BS_OWNERDRAW;
		}
		break;
	case WM_MOUSEMOVE:
		{
			if(g_wMouseTrack!=(DWORD)hWnd)
			{
				TRACKMOUSEEVENT tme;
				tme.cbSize = sizeof(tme);
				tme.hwndTrack = hWnd;
				tme.dwFlags = TME_LEAVE | TME_HOVER;
				tme.dwHoverTime = 1;
				if(_TrackMouseEvent(&tme))
					g_wMouseTrack=(DWORD)hWnd;
			}
		}
		break;
	case WM_MOUSEHOVER:
		{
			g_wHover=(DWORD)hWnd;
			InvalidateRect(hWnd,NULL,TRUE);
		}
		break;
	case WM_MOUSELEAVE:
		{
			g_wHover=0;
			g_wMouseTrack=0;
			InvalidateRect(hWnd,NULL,TRUE);
		}
		break;
	}
	return CallWindowProc(g_lpOldButtonProcWnd, hWnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK ProcDialogWnd(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_ERASEBKGND :
		{
			HDC hDC = (HDC)(wParam); 
			RECT rc;
			::GetClientRect(hWnd,&rc);
			HBITMAP hBitmap=::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_DIALOG));
			HDC tempHDC =::CreateCompatibleDC(hDC); 
			HBITMAP oldBit=(HBITMAP)SelectObject(tempHDC,hBitmap);
			StretchBlt(hDC,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top,tempHDC,5,25,100,150,SRCCOPY);
			SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_DIALOGBOTTOM)));
			StretchBlt(hDC,rc.left,rc.bottom-40,rc.right-rc.left,120,tempHDC,0,0,100,100,SRCCOPY);
			::DeleteObject(tempHDC); 
			ReleaseDC(hWnd,hDC);
		}
		return 1;
	case WM_CTLCOLORSTATIC:
		{
			HDC hDC = (HDC)(wParam);
			::SetBkMode(hDC,TRANSPARENT);
		}
		return (DWORD)GetStockObject(NULL_BRUSH);
	case WM_MOVE:
	case WM_NOTIFY:
	case WM_NCACTIVATE:
	case WM_NCPAINT:
		{
			LRESULT lrst=CallWindowProc(g_lpOldDialogProcWnd, hWnd, uMsg, wParam, lParam);
			//TRACE("Be Paint\n");
			HDC hDC=GetWindowDC(hWnd);
			int nBorderWidth=GetSystemMetrics(SM_CXFRAME);
			int nBorderHeight=GetSystemMetrics(SM_CYFRAME);
			int nTitleHeight=GetSystemMetrics(SM_CYSIZE);
			RECT rcWnd,rcButton;
			GetWindowRect(hWnd,&rcWnd);
			HDC tempHDC=::CreateCompatibleDC(hDC);
			SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_DIALOG)));
			StretchBlt(hDC,nBorderWidth-1,nBorderHeight-1,rcWnd.right-rcWnd.left-2*nBorderWidth+1,nTitleHeight+1,tempHDC,3,3,20,20,SRCCOPY);
			::DrawIconEx(hDC, nBorderWidth, nBorderHeight, AfxGetApp()->LoadIcon(IDR_MAINFRAME), 16, 16, 0, NULL, DI_NORMAL);
			
			//�ػ�button
			rcButton.right=rcWnd.right-rcWnd.left-nBorderWidth;
			rcButton.left=rcButton.right-19;
			rcButton.top = nBorderHeight;
			rcButton.bottom = rcButton.top + 19;
			SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_EXIT_NORM)));
			BitBlt(hDC,rcButton.left,rcButton.top,rcButton.right-rcButton.left,rcButton.bottom-rcButton.top,tempHDC,0,0,SRCCOPY);
			LONG lWndStyle=GetWindowLong(hWnd,GWL_STYLE);
			if(lWndStyle&WS_MAXIMIZEBOX)
			{
				rcButton.right = rcButton.left-1;
				rcButton.left = rcButton.right - 19;
				if(IsZoomed(hWnd))
					SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_RESTORE_NORM)));
				else
					SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_MAX_NORM)));
				BitBlt(hDC,rcButton.left,rcButton.top,rcButton.right-rcButton.left,rcButton.bottom-rcButton.top,tempHDC,0,0,SRCCOPY);
			}
			if(lWndStyle&WS_MINIMIZEBOX)
			{	
				rcButton.right = rcButton.left-1;
				rcButton.left = rcButton.right - 19;
				SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_MIN_MORM)));
				BitBlt(hDC,rcButton.left,rcButton.top,rcButton.right-rcButton.left,rcButton.bottom-rcButton.top,tempHDC,0,0,SRCCOPY);
			}
			
			//�ػ�caption
			int nOldMode =SetBkMode(hDC,TRANSPARENT);
			COLORREF clOldText=SetTextColor(hDC,0x00FFFFFF);
			CRect rtTitle;
			rtTitle.left = 18+nBorderWidth; 
			rtTitle.top = nBorderHeight;
			rtTitle.bottom = rtTitle.top + 30;
			rtTitle.right=rcWnd.right-rcWnd.left;
			TCHAR lpszTitle[255];
			GetWindowText(hWnd,lpszTitle,255);
			DrawText(hDC,&lpszTitle[0],strlen(lpszTitle),&rtTitle,DT_LEFT);
			
			SetBkMode(hDC,nOldMode);
			SetTextColor(hDC,clOldText);

			::DeleteObject(tempHDC); 
			ReleaseDC(hWnd,hDC);
			return lrst;
		}
	case WM_NCMOUSEMOVE:
		{
			HDC hDC=GetWindowDC(hWnd);
			int nBorderWidth=GetSystemMetrics(SM_CXFRAME);
			int nBorderHeight=GetSystemMetrics(SM_CYFRAME);
			int nTitleHeight=GetSystemMetrics(SM_CYSIZE);
			RECT rcWnd,rcButton;
			GetWindowRect(hWnd,&rcWnd);
			HDC tempHDC=::CreateCompatibleDC(hDC);
			
			//�ػ�button
			rcButton.right=rcWnd.right-rcWnd.left-nBorderWidth;
			rcButton.left=rcButton.right-19;
			rcButton.top = nBorderHeight;
			rcButton.bottom = rcButton.top + 19;
			if(wParam==HTCLOSE)
				SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_EXIT_FOCUSE)));
			else
				SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_EXIT_NORM)));
			BitBlt(hDC,rcButton.left,rcButton.top,rcButton.right-rcButton.left,rcButton.bottom-rcButton.top,tempHDC,0,0,SRCCOPY);
			LONG lWndStyle=GetWindowLong(hWnd,GWL_STYLE);
			if(lWndStyle&WS_MAXIMIZEBOX)
			{
				if(wParam==HTMAXBUTTON)
					if(IsZoomed(hWnd))
						SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_RESTORE_FOCUSE)));
					else
						SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_MAX_FOCUSE)));
				else
					if(IsZoomed(hWnd))
						SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_RESTORE_NORM)));
					else
						SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_MAX_NORM)));
				rcButton.right = rcButton.left-1;
				rcButton.left = rcButton.right - 19;
				BitBlt(hDC,rcButton.left,rcButton.top,rcButton.right-rcButton.left,rcButton.bottom-rcButton.top,tempHDC,0,0,SRCCOPY);
			}
			if(lWndStyle&WS_MINIMIZEBOX)
			{
				if(wParam==HTMINBUTTON)
					SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_MIN_FOCUSE)));
				else
					SelectObject(tempHDC,::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_MIN_MORM)));
				rcButton.right = rcButton.left-1;
				rcButton.left = rcButton.right - 19;
				BitBlt(hDC,rcButton.left,rcButton.top,rcButton.right-rcButton.left,rcButton.bottom-rcButton.top,tempHDC,0,0,SRCCOPY);
			}
			
			::DeleteObject(tempHDC); 
			ReleaseDC(hWnd,hDC);
		}
		break;
	case WM_NCLBUTTONDOWN:
		{
			switch(wParam)
			{
			case HTCLOSE:
				SendMessage(hWnd,WM_CLOSE,0,0);
				return 0;
			case HTMINBUTTON:
				SendMessage(hWnd,WM_SYSCOMMAND,SC_MINIMIZE,lParam);
				return 0;
			case HTMAXBUTTON:
				if(IsZoomed(hWnd))
					SendMessage(hWnd,WM_SYSCOMMAND,SC_RESTORE,lParam);
				else
					SendMessage(hWnd,WM_SYSCOMMAND,SC_MAXIMIZE,lParam);
				return 0;
			}
		}
		break;
	case WM_DRAWITEM:
		{
			LPDRAWITEMSTRUCT lpDrawItem = (LPDRAWITEMSTRUCT) lParam;
			
			CDC* pDC=CDC::FromHandle(lpDrawItem->hDC);
			int nSaveDC=pDC->SaveDC();
			UINT state = lpDrawItem->itemState;
			CRect rc =  lpDrawItem->rcItem;
			CDC* pDisplayMemDC=new CDC;
			pDisplayMemDC->CreateCompatibleDC(pDC);		
			pDisplayMemDC->SelectObject(::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_XPBUTTONS)));			
			if(state&ODS_SELECTED || state&ODS_FOCUS)
				pDC->StretchBlt(rc.left,rc.top,rc.Width(),rc.Height(),pDisplayMemDC,83,0,83,34,SRCCOPY);
			else if(g_wHover==(DWORD)lpDrawItem->hwndItem)
				pDC->StretchBlt(rc.left,rc.top,rc.Width(),rc.Height(),pDisplayMemDC,0,0,83,34,SRCCOPY);
			else
				pDC->StretchBlt(rc.left,rc.top,rc.Width(),rc.Height(),pDisplayMemDC,166,0,83,34,SRCCOPY);
			
			ReleaseDC(hWnd,pDisplayMemDC->m_hDC);
			delete pDisplayMemDC;
			
			TCHAR strText[MAX_PATH + 1];
			::GetWindowText(lpDrawItem->hwndItem, strText, MAX_PATH);
			if (strText!=NULL)
			{
				CString strTitle=strText;
				strTitle.Remove('&');
				CSize szExtent = pDC->GetTextExtent(strTitle, strTitle.GetLength());
				CPoint pt( rc.CenterPoint().x - szExtent.cx / 2, rc.CenterPoint().y - szExtent.cy / 2);
				if (state & ODS_SELECTED) 
					pt.Offset(1, 1);
				int nMode = pDC->SetBkMode(TRANSPARENT);
				if (state & ODS_DISABLED)
					pDC->DrawState(pt, szExtent, strText, DSS_DISABLED, TRUE, 0, (HBRUSH)NULL);
				else
					pDC->DrawState(pt, szExtent, strText, DSS_NORMAL, TRUE, 0, (HBRUSH)NULL);
				pDC->SetBkMode(nMode);
			} 
			return TRUE;
		}
		break;
	}
	return CallWindowProc(g_lpOldDialogProcWnd, hWnd, uMsg, wParam, lParam);
}

