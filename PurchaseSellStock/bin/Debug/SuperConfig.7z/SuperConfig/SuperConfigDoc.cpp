// SuperConfigDoc.cpp : implementation of the CSuperConfigDoc class
//

#include "stdafx.h"
#include "SuperConfig.h"

#include "SuperConfigDoc.h"
#include "CntrItem.h"

#include "MainFrm.h"
#include "ftp.h"
#include "SuperConfigView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const char CSuperConfigDoc::m_alphabet[] =TEXT("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
const BYTE CSuperConfigDoc::m_decTab[256] = {
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255,  62, 255, 255, 255,  63,  52,  53,  54,  55,  56,  57,  58,  59,  60,  61, 255, 255,
		255, 255, 255, 255, 255,  0,   1,    2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,
		15,   16,  17,  18,  19,  20,  21,  22,  23,  24,  25, 255, 255, 255, 255, 255, 255,  26,  27,  28,
		29,   30,  31,  32,  33,  34,  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,  45,  46,  47,  48,
		49,   50,  51, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};


/////////////////////////////////////////////////////////////////////////////
// CSuperConfigDoc

IMPLEMENT_DYNCREATE(CSuperConfigDoc, CRichEditDoc)

BEGIN_MESSAGE_MAP(CSuperConfigDoc, CRichEditDoc)
	//{{AFX_MSG_MAP(CSuperConfigDoc)
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, CRichEditDoc::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, CRichEditDoc::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, CRichEditDoc::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigDoc construction/destruction

CSuperConfigDoc::CSuperConfigDoc()
{
	m_bRTF=FALSE;
}

CSuperConfigDoc::~CSuperConfigDoc()
{
}

BOOL CSuperConfigDoc::OnNewDocument()
{
	if (!CRichEditDoc::OnNewDocument())
		return FALSE;

	return TRUE;
}

CRichEditCntrItem* CSuperConfigDoc::CreateClientItem(REOBJECT* preo) const
{
	// cast away constness of this
	return new CSuperConfigCntrItem(preo, (CSuperConfigDoc*) this);
}

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigDoc serialization

void CSuperConfigDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
	// TODO: set CRichEditDoc::m_bRTF = FALSE if you are serializing as text
	m_bRTF=FALSE;
	CRichEditDoc::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigDoc diagnostics

#ifdef _DEBUG
void CSuperConfigDoc::AssertValid() const
{
	CRichEditDoc::AssertValid();
}

void CSuperConfigDoc::Dump(CDumpContext& dc) const
{
	CRichEditDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigDoc commands

BOOL CSuperConfigDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	//AfxMessageBox(lpszPathName);
	ParsePathName(lpszPathName);
	if(m_bLocal)
	{
		m_sPathName=m_sTitle;
	}
	else
	{
		if(theApp.GetRFilesEncode(m_sName))
		{
			CString stemp=DeCodeFile(m_sLocalPath);
			if(stemp.IsEmpty())
			{
				CStdioFile stdiofile;
				if(stdiofile.Open(m_sLocalPath, CStdioFile::modeReadWrite | CStdioFile ::modeCreate))
				{
					stdiofile.WriteString("���󣡽����ļ�ʧ�ܣ�");
					stdiofile.Close();
				}
				else
					return FALSE;
					
			}
			else
				m_sPathName=stemp;
		}
		else
			m_sPathName=m_sLocalPath;
	}

	if (!CRichEditDoc::OnOpenDocument(m_sPathName))
		return FALSE;
	
	return TRUE;
}

CString CSuperConfigDoc::ParsePathName(LPCTSTR lpszPathName, BOOL bChange)
{
	CString sTitle;
	sTitle.Empty();

	if(lpszPathName[0]=='C')
	{
		TCHAR lpszIP[20];
		TCHAR lpszFTPFlag[20];
		TCHAR lpszUsr[20];
		TCHAR lpszPwd[20];
		TCHAR lpszName[100];
		TCHAR lpszTime[20];
		TCHAR lpszLocalPath[MAX_PATH];

		CString sRemotePath;
		int i=3,nIndex;
		
		nIndex=0;
		while(lpszPathName[i]!='\0')
		{
			if(lpszPathName[i]=='\\')
			{
				i++;
				break;
			}	
			if(nIndex<20)
				lpszFTPFlag[nIndex++]=lpszPathName[i];
			i++;
		}
		lpszFTPFlag[nIndex]='\0';
		if(strcmp(lpszFTPFlag,"FTP_SUPERCONFIG")!=0)
		{
			sTitle=lpszPathName;
			if(bChange)
			{
				m_bLocal=TRUE;
				int i=0,nIndex=0;
				while(lpszPathName[i]!='\0')
				{
					if(lpszPathName[i]=='\\' || lpszPathName[i]=='/')
						nIndex=i+1;
					i++;
				}
				m_sName=lpszPathName+nIndex;
				m_sTitle=sTitle;
			}
		}
		else
		{
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}
				if(nIndex<20)
					lpszIP[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszIP[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<20)
					lpszUsr[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszUsr[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<20)
					lpszPwd[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszPwd[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<100)
					lpszName[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszName[nIndex]='\0';

			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<20)
					lpszTime[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszTime[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0' && nIndex<MAX_PATH)
				lpszLocalPath[nIndex++]=lpszPathName[i++];
			lpszLocalPath[nIndex]='\0';

			sRemotePath=theApp.GetRFilesPathName(lpszName);
			sTitle.Format("FTP:\\%s@%s %s",lpszUsr,lpszIP,sRemotePath);
			
			if(bChange)
			{
				m_bLocal=FALSE;
				m_sName=lpszName;
				m_sPwd=lpszPwd;
				m_sRemotePath=sRemotePath;
				m_sServer=lpszIP;
				m_sTitle=sTitle;
				m_sUsr=lpszUsr;
				m_sTitle=sTitle;
				m_sLocalPath=lpszLocalPath;
				m_sTime=lpszTime;
			}
		}
		
	}
	else
	{
		sTitle=lpszPathName;
		if(bChange)
		{
			m_bLocal=TRUE;
			int i=0,nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\' || lpszPathName[i]=='/')
					nIndex=i+1;
				i++;
			}
			m_sName=lpszPathName+nIndex;
			m_sTitle=sTitle;
		}
	}
	return sTitle;
}

void CSuperConfigDoc::SetTitle(LPCTSTR lpszTitle) 
{	
	if(m_sTitle.IsEmpty())
		CRichEditDoc::SetTitle(lpszTitle);
	else
	{
		CRichEditDoc::SetTitle(m_sTitle);
		m_strPathName=m_sPathName;
	}	
}

CString CSuperConfigDoc::EnCodeFile(CString strSrcFile)
{
	FILE *pfSrc,*pfDst;
	char szTempName[MAX_PATH];
    char lpBuffer[4096];
	char OutMsg[5462];
	int nLen;
	BOOL bNewLine;
	
	pfSrc=fopen(strSrcFile,"r");
	if(pfSrc==NULL)
		return "";

	GetTempPath(4096,lpBuffer);
	GetTempFileName(lpBuffer, "CFG",0,szTempName);
	
	pfDst=fopen(szTempName,"w");
	if(pfDst==NULL)
	{
		fclose(pfSrc);
		return "";
	}

	EnCodeString(";zxin10config",OutMsg);
	fputs(OutMsg,pfDst);
	fputs("\n",pfDst);

	while(!feof(pfSrc))
	{
		memset(lpBuffer,0,4096);
		fgets(lpBuffer,4096,pfSrc);
		nLen=strlen(lpBuffer);
		if(lpBuffer[nLen-1]=='\x0A')
		{
			bNewLine=TRUE;
			lpBuffer[nLen-1]='\0';
		}
		else
			bNewLine=FALSE;

		EnCodeString(lpBuffer,OutMsg);

		fputs(OutMsg,pfDst);
		if(bNewLine)
			fputs("\n",pfDst);
	}

	fclose(pfSrc);
	fclose(pfDst);

	return szTempName;
	
}

CString CSuperConfigDoc::DeCodeFile(CString strSrcFile)
{
	FILE *pfSrc,*pfDst;
	char szTempName[MAX_PATH];
    char lpBuffer[4096];
	char OutMsg[4096];
	int nLen;
	BOOL bNewLine;
	
	pfSrc=fopen(strSrcFile,"r");
	if(pfSrc==NULL)
		return "";
	
	GetTempPath(4096,lpBuffer);
	GetTempFileName(lpBuffer, "CFG",0,szTempName);
	
	pfDst=fopen(szTempName,"w");
	if(pfDst==NULL)
	{
		fclose(pfSrc);
		return "";
	}
	
	while(!feof(pfSrc))
	{
		memset(lpBuffer,0,4096);
		fgets(lpBuffer,4096,pfSrc);
		nLen=strlen(lpBuffer);
		if(lpBuffer[nLen-1]=='\x0A')
		{
			bNewLine=TRUE;
			lpBuffer[nLen-1]='\0';
		}
		else
			bNewLine=FALSE;
		
		DeCodeString(lpBuffer,OutMsg);
		if(strncmp(OutMsg,";zxin10config",strlen(";zxin10config")) == 0)
			continue;

		fputs(OutMsg,pfDst);
		if(bNewLine)
			fputs("\n",pfDst);
	}
	
	fclose(pfSrc);
	fclose(pfDst);
	
	return szTempName;
	return "";
}

void CSuperConfigDoc::EnCodeString(const char *pSrc,char *pOut)
{
	int srclen=strlen(pSrc);
	UINT32 buf;
	int i,codelen=srclen/3;
	BYTE *p=(BYTE *)pSrc;
	char *r=pOut;
	
	for(i=0;i<codelen;i++)
	{
		buf = (*p << 16) | (*(p + 1) << 8) | *(p + 2);
		p += 3;
		*r++ = m_alphabet[(buf >> 18) & 0x3F];
		*r++ = m_alphabet[(buf >> 12) & 0x3F];
		*r++ = m_alphabet[(buf >> 6) & 0x3F];
		*r++ = m_alphabet[buf & 0x3F];
	}

	if(srclen%3)
	{
		BYTE tmp[3];
		if(srclen%3==1)
		{
			tmp[0]=*p;
			tmp[1]=' ';
			tmp[2]=' ';
		}
		else if(srclen%3==2)
		{
			tmp[0]=*p;
			tmp[1]=*(p+1);
			tmp[2]=' ';
		}
		buf = (tmp[0] << 16) | (tmp[1] << 8) | tmp[2];
		*r++ = m_alphabet[(buf >> 18) & 0x3F];
		*r++ = m_alphabet[(buf >> 12) & 0x3F];
		*r++ = m_alphabet[(buf >> 6) & 0x3F];
		*r++ = m_alphabet[buf & 0x3F];
	}
	*r=0;
}

void CSuperConfigDoc::DeCodeString(const char *pSrc, char *pOut)
{
	UINT32 buf;
	int nLen=strlen(pSrc);
	char *p=(char*)pSrc;
	
	if(nLen == 0|| nLen%4!=0 ) 
	{
		*pOut=0;
		return;
	}
	while(*p)
	{
		buf = ((m_decTab[*p] & 0x3F) << 18) | ((m_decTab[*(p + 1)] & 0x3F) << 12) | ((m_decTab[*(p + 2)] & 0x3F) << 6) | (m_decTab[*(p + 3)] & 0x3F);
		p += 4;
		*pOut++ = (buf >> 16) & 0xFF;
		*pOut++ = (buf >> 8) & 0xFF;
		*pOut++ = buf & 0xFF;            
	}
	*pOut=0;
}

BOOL CSuperConfigDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	if (!CRichEditDoc::OnSaveDocument(lpszPathName))
		return FALSE;
	
	CString strFileName;
	int i=0,nIndex=0;
	
	while(lpszPathName[i]!='\0')
	{
		if(lpszPathName[i]=='\\')
			nIndex=i+1;
		i++;
	}
	strFileName=lpszPathName+nIndex;

	if(strFileName.Right(4)==".tmp" && m_bLocal==FALSE)
	{
		if(FTPGetTime(m_sServer,m_sUsr,m_sPwd,m_sRemotePath)!=m_sTime)
		{
			CString sMessage;
			sMessage.Format("%s �ļ�����򿪺��ѱ������޸ģ��Ƿ�Ҫ���ǵ����˵��޸ģ�",m_sName);
			if(AfxMessageBox(sMessage,MB_YESNO|MB_ICONWARNING)==IDNO)
				return FALSE;
		}
		CString strtmpPath=lpszPathName;
		if(theApp.GetRFilesEncode(m_sName))
		{
			strtmpPath=EnCodeFile(m_sPathName);
			if(strtmpPath=="")
				return FALSE;
		}
		CString sTime;
		sTime.Empty();
		sTime=FTPUpLoad(m_sServer,m_sUsr,m_sPwd,m_sRemotePath,strtmpPath);
		if(sTime.IsEmpty())
			return FALSE;
		m_sTime=sTime;
	}
	else
	{
		m_bLocal=TRUE;
		m_sName=strFileName;
		m_sTitle=lpszPathName;
		m_sPathName=lpszPathName;
		
		POSITION pos=GetFirstViewPosition();
		if(pos!=NULL)
		{
			CView* pView=GetNextView(pos);
			CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
			pMainFrame->m_wndTabBar.SetText((DWORD)pView->GetParent(),m_sName);
			pMainFrame->m_wndTabBar.SetTip((DWORD)pView->GetParent(),m_sTitle);
			pMainFrame->m_wndTabBar.SetShowIcon((DWORD)pView->GetParent(),CTabBar::iconLocal);
		}	
	}	
	return TRUE;	
}

BOOL CSuperConfigDoc::IsAlreadyOpen(LPCTSTR lpszPathName)
{
	CString sTitle;
	sTitle.Empty();

	if(lpszPathName[0]=='C')
	{
		TCHAR lpszIP[20];
		TCHAR lpszFTPFlag[20];
		TCHAR lpszUsr[20];
		TCHAR lpszPwd[20];
		TCHAR lpszName[100];
		TCHAR lpszTime[20];
		TCHAR lpszLocalPath[MAX_PATH];

		CString sRemotePath;
		int i=3,nIndex;
		
		nIndex=0;
		while(lpszPathName[i]!='\0')
		{
			if(lpszPathName[i]=='\\')
			{
				i++;
				break;
			}	
			if(nIndex<20)
				lpszFTPFlag[nIndex++]=lpszPathName[i];
			i++;
		}
		lpszFTPFlag[nIndex]='\0';
		if(strcmp(lpszFTPFlag,"FTP_SUPERCONFIG")!=0)
		{
			sTitle=lpszPathName;
		}
		else
		{
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}
				if(nIndex<20)
					lpszIP[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszIP[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<20)
					lpszUsr[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszUsr[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<20)
					lpszPwd[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszPwd[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<100)
					lpszName[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszName[nIndex]='\0';

			nIndex=0;
			while(lpszPathName[i]!='\0')
			{
				if(lpszPathName[i]=='\\')
				{
					i++;
					break;
				}	
				if(nIndex<20)
					lpszTime[nIndex++]=lpszPathName[i];
				i++;
			}
			lpszTime[nIndex]='\0';
			
			nIndex=0;
			while(lpszPathName[i]!='\0' && nIndex<MAX_PATH)
				lpszLocalPath[nIndex++]=lpszPathName[i++];
			lpszLocalPath[nIndex]='\0';

			sRemotePath=theApp.GetRFilesPathName(lpszName);
			sTitle.Format("FTP:\\%s@%s %s",lpszUsr,lpszIP,sRemotePath);
		}
		
	}
	else
	{
		sTitle=lpszPathName;
	}
	return (m_sTitle==sTitle);
}
