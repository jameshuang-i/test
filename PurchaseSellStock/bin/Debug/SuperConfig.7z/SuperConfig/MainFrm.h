// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__A06EA018_ED88_4727_987B_EF51063D4680__INCLUDED_)
#define AFX_MAINFRM_H__A06EA018_ED88_4727_987B_EF51063D4680__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	//CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
public:
	CTabBar		m_wndTabBar;


// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnToolbarDropDown(NMHDR* pNotifyStruct, LRESULT *plr);
	afx_msg void OnFileOpenServer();
	afx_msg void OnTabBarClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTabBarDBClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTabBarRClick(NMHDR* pNMHDR, LRESULT* pResult); 
	afx_msg void OnConfigServerfile();
	afx_msg void OnFileSaveAll();
	afx_msg void OnFileCloseAll();
	afx_msg void OnConfigHightlight();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__A06EA018_ED88_4727_987B_EF51063D4680__INCLUDED_)
