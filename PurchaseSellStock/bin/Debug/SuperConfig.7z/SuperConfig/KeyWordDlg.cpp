// KeyWordDlg.cpp : implementation file
//

#include "stdafx.h"
#include "superconfig.h"
#include "KeyWordDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CKeyWordDlg dialog


CKeyWordDlg::CKeyWordDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CKeyWordDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CKeyWordDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CKeyWordDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CKeyWordDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CKeyWordDlg, CDialog)
	//{{AFX_MSG_MAP(CKeyWordDlg)
	ON_BN_CLICKED(ID_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CKeyWordDlg message handlers

void CKeyWordDlg::OnOk() 
{
	CString sFileName,sSectionName,sValue;
	GetDlgItem(IDC_FILE)->GetWindowText(sFileName);
	GetDlgItem(IDC_SECTION)->GetWindowText(sSectionName);
	GetDlgItem(IDC_KEYWORD)->GetWindowText(sValue);

	theApp.AddKeyWord(sFileName,sSectionName,sValue);
	EndDialog(0);
}
