// SuperConfigView.h : interface of the CSuperConfigView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SUPERCONFIGVIEW_H__6AFA101A_6959_48DA_A2E6_854BC810F95D__INCLUDED_)
#define AFX_SUPERCONFIGVIEW_H__6AFA101A_6959_48DA_A2E6_854BC810F95D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSuperConfigCntrItem;

class CSuperConfigView : public CRichEditView
{
protected: // create from serialization only
	CSuperConfigView();
	DECLARE_DYNCREATE(CSuperConfigView)

// Attributes
public:
	CSuperConfigDoc* GetDocument();

	typedef struct _INISECTION 
	{
		TCHAR lpszName[255];
		int nStartLine;
		long lEndLine;
	}INISECTION;

	typedef struct _COLORITEM
	{
		int x;
		int y;
		int nStart;
		int nLength;
		_COLORITEM* next;
	}COLORITEM;

private:
	TCHAR * m_pBuffer;
	void DrawSyncColor();
	CFont m_font;
	BOOL m_bCanPaint;
	BOOL m_bInForcedChange;
	CHARRANGE m_crOldSel;
	BOOL m_bShowModified;
	int m_nCaretLine;
	int m_nCharHeight;
	CArray <INISECTION*,INISECTION*>	m_pArraySection;
	COLORITEM* m_pSectionHeader;
	COLORITEM* m_pKeyHeader;
	COLORITEM* m_pValueHeader;
	COLORITEM* m_pCommitHeader;


// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperConfigView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
public:
	DWORD GetColorItem(_COLORITEM** pHead);
	BOOL PraseINI(TCHAR* pbuffer,long FirstCharIndex);
	void PraseSection();
	virtual ~CSuperConfigView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	
// Generated message map functions
protected:
	void SetSectionBar(int nLine);
	//{{AFX_MSG(CSuperConfigView)
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSectionClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnPaint();
	afx_msg void OnToolFresh();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnViewSynchight();
	afx_msg void OnUpdateViewSynchight(CCmdUI* pCmdUI);
	afx_msg void OnToolFormat();
	afx_msg void CSuperConfigView::OnRestartServer();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SuperConfigView.cpp
inline CSuperConfigDoc* CSuperConfigView::GetDocument()
   { return (CSuperConfigDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPERCONFIGVIEW_H__6AFA101A_6959_48DA_A2E6_854BC810F95D__INCLUDED_)
