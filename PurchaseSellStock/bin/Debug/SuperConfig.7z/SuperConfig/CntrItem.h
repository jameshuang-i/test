// CntrItem.h : interface of the CSuperConfigCntrItem class
//

#if !defined(AFX_CNTRITEM_H__6A35A5D1_693F_4E3A_8448_4938167CAF39__INCLUDED_)
#define AFX_CNTRITEM_H__6A35A5D1_693F_4E3A_8448_4938167CAF39__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSuperConfigDoc;
class CSuperConfigView;

class CSuperConfigCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CSuperConfigCntrItem)

// Constructors
public:
	CSuperConfigCntrItem(REOBJECT* preo = NULL, CSuperConfigDoc* pContainer = NULL);

// Attributes
public:
	CSuperConfigDoc* GetDocument()
		{ return (CSuperConfigDoc*)CRichEditCntrItem::GetDocument(); }
	CSuperConfigView* GetActiveView()
		{ return (CSuperConfigView*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperConfigCntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CSuperConfigCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__6A35A5D1_693F_4E3A_8448_4938167CAF39__INCLUDED_)
