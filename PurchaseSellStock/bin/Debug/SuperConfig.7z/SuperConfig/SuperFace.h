// SuperFace.h: interface for the SuperFace class.
//
//////////////////////////////////////////////////////////////////////

//#if !defined(AFX_SUPERFACE_H__8262E50C_18A8_4058_96B6_C2994DC2E924__INCLUDED_)
//#define AFX_SUPERFACE_H__8262E50C_18A8_4058_96B6_C2994DC2E924__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WNDCLASSNAME_DAILOG "#32770"
#define WNDCLASSNAME_BUTTON "Button"

BOOL HookDialogWndClass();
LRESULT CALLBACK ProcDialogWnd(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);

BOOL HookButtonWndClass();
LRESULT CALLBACK ProcButtonWnd(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);


//#endif // !defined(AFX_SUPERFACE_H__8262E50C_18A8_4058_96B6_C2994DC2E924__INCLUDED_)
