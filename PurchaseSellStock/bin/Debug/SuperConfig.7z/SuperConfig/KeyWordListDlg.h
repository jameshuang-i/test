#if !defined(AFX_KEYWORDLISTDLG_H__690BE430_35F0_4809_BE55_1CF8D8A77D00__INCLUDED_)
#define AFX_KEYWORDLISTDLG_H__690BE430_35F0_4809_BE55_1CF8D8A77D00__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// KeyWordListDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CKeyWordListDlg dialog

class CKeyWordListDlg : public CDialog
{
// Construction
public:
	void ReLoadList();
	CKeyWordListDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CKeyWordListDlg)
	enum { IDD = IDD_KEYWORDLISTBOX };
	CListCtrl	m_ctrList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CKeyWordListDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CKeyWordListDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	afx_msg void OnDel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_KEYWORDLISTDLG_H__690BE430_35F0_4809_BE55_1CF8D8A77D00__INCLUDED_)
