// CntrItem.cpp : implementation of the CSuperConfigCntrItem class
//

#include "stdafx.h"
#include "SuperConfig.h"

#include "SuperConfigDoc.h"
#include "SuperConfigView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigCntrItem implementation

IMPLEMENT_SERIAL(CSuperConfigCntrItem, CRichEditCntrItem, 0)

CSuperConfigCntrItem::CSuperConfigCntrItem(REOBJECT* preo, CSuperConfigDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
}

CSuperConfigCntrItem::~CSuperConfigCntrItem()
{
}

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigCntrItem diagnostics

#ifdef _DEBUG
void CSuperConfigCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CSuperConfigCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
