// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "SuperConfig.h"

#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_FORMAT_BAR, OnViewFormatBar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FORMAT_BAR, OnUpdateViewFormatBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.style = WS_CHILD | WS_VISIBLE | WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU
		| FWS_ADDTOTITLE | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX;

	return TRUE;
}

void CChildFrame::ActivateFrame(int nCmdShow)
{
	nCmdShow = SW_SHOWMAXIMIZED;
	CMDIChildWnd::ActivateFrame(nCmdShow);
}


/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndFormatBar.Create(this))
	{
		TRACE0("Failed to create sectionbar\n");
		return -1;      // fail to create
	}
	m_wndFormatBar.EnableDocking(CBRS_ALIGN_LEFT|CBRS_ALIGN_RIGHT);
	EnableDocking(CBRS_ALIGN_LEFT|CBRS_ALIGN_RIGHT);
	DockControlBar(&m_wndFormatBar,AFX_IDW_DOCKBAR_RIGHT);
	
	return 0;
}

void CChildFrame::OnViewFormatBar() 
{
	if(m_wndFormatBar.IsWindowVisible())
	{
		m_wndFormatBar.ShowWindow(SW_HIDE);
		WriteProfileString("GENERAL","IsShowFromatBar","0");
	}
	else
	{
		m_wndFormatBar.ShowWindow(SW_SHOW);
		WriteProfileString("GENERAL","IsShowFromatBar","1");
	}
	RecalcLayout();	
}

void CChildFrame::OnUpdateViewFormatBar(CCmdUI* pCmdUI) 
{
	if(m_wndFormatBar.IsWindowVisible())
		pCmdUI->SetCheck(TRUE);
	else
		pCmdUI->SetCheck(FALSE);
}
