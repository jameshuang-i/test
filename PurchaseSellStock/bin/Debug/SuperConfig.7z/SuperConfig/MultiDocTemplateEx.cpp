// MultiDocTemplateEx.cpp: implementation of the CMultiDocTemplateEx class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MultiDocTemplateEx.h"

#include "SuperConfigDoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMultiDocTemplateEx::CMultiDocTemplateEx(UINT nIDResource, CRuntimeClass* pDocClass, CRuntimeClass* pFrameClass, CRuntimeClass* pViewClass)
 : CMultiDocTemplate(nIDResource, pDocClass, pFrameClass, pViewClass)
{

}

CMultiDocTemplateEx::~CMultiDocTemplateEx()
{

}

CMultiDocTemplateEx::Confidence CMultiDocTemplateEx::MatchDocType(LPCTSTR lpszPath,CDocument *&rpDocMatch)
{
    Confidence match = CMultiDocTemplate::MatchDocType(lpszPath, rpDocMatch);
	
	if(match!=yesAlreadyOpen)
	{
		POSITION pos = GetFirstDocPosition();
		while (pos != NULL)
		{
			CSuperConfigDoc* pDoc =(CSuperConfigDoc*) GetNextDoc(pos);
			if (pDoc->IsAlreadyOpen(lpszPath))
			{
				match=yesAlreadyOpen;
				pDoc->OnOpenDocument(lpszPath);
				rpDocMatch = pDoc;
				break;
			}
		}
	}
    return match;
}
