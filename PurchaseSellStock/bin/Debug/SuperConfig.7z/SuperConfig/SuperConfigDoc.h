// SuperConfigDoc.h : interface of the CSuperConfigDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SUPERCONFIGDOC_H__1F149430_3B3B_43F4_BC78_176603F76C12__INCLUDED_)
#define AFX_SUPERCONFIGDOC_H__1F149430_3B3B_43F4_BC78_176603F76C12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CSuperConfigDoc : public CRichEditDoc
{
protected: // create from serialization only
	CSuperConfigDoc();
	DECLARE_DYNCREATE(CSuperConfigDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperConfigDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void SetTitle(LPCTSTR lpszTitle);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL
	virtual CRichEditCntrItem* CreateClientItem(REOBJECT* preo) const;

private:
	static const char m_alphabet[];
	static const BYTE m_decTab[];

// Implementation
public:
	BOOL IsAlreadyOpen(LPCTSTR lpszPath);
	CString m_sLocalPath;
	CString m_sTime;
	CString m_sPathName;
	CString m_sRemotePath;
	CString m_sPwd;
	CString m_sUsr;
	CString m_sServer;
	CString m_sName;
	BOOL m_bLocal;
	CString m_sTitle;

	CString ParsePathName(LPCTSTR lpszPathName,BOOL bChange=TRUE);
	void DeCodeString(const char *pSrc,char *pOut);
	void EnCodeString(const char *pSrc,char *pOut);
	CString DeCodeFile(CString strSrcFile);
	CString EnCodeFile(CString strSrcFile);
	virtual ~CSuperConfigDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSuperConfigDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPERCONFIGDOC_H__1F149430_3B3B_43F4_BC78_176603F76C12__INCLUDED_)
