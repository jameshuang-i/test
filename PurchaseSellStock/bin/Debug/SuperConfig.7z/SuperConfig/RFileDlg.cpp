// RFileDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SuperConfig.h"
#include "RFileDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRFileDlg dialog


CRFileDlg::CRFileDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRFileDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRFileDlg)
	m_nOperatType=0;
	m_bEnCode = FALSE;
	//}}AFX_DATA_INIT
}


void CRFileDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRFileDlg)
	DDX_Check(pDX, IDC_ENCODE, m_bEnCode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRFileDlg, CDialog)
	//{{AFX_MSG_MAP(CRFileDlg)
	ON_BN_CLICKED(ID_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRFileDlg message handlers

BOOL CRFileDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(m_nOperatType==0)
	{
		SetWindowText("����Զ���ļ�����");
		GetDlgItem(IDC_NAME)->EnableWindow();
	}
	else
	{
		SetWindowText("�޸�Զ���ļ�����");
		GetDlgItem(IDC_NAME)->SetWindowText(m_sName);
		GetDlgItem(IDC_NAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_PATH)->SetWindowText(theApp.GetRFilesPathName(m_sName));
		if(theApp.GetRFilesEncode(m_sName))
			m_bEnCode=TRUE;
		else
			m_bEnCode=FALSE;
		UpdateData(FALSE);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRFileDlg::OnOk() 
{
	CString sName,sPath;
	GetDlgItem(IDC_NAME)->GetWindowText(sName);
	GetDlgItem(IDC_PATH)->GetWindowText(sPath);
	UpdateData();

	if(m_nOperatType==0)
	{
		if(theApp.IsRFileExist(sName))
		{
			AfxMessageBox("������������ļ����Ѿ����ڣ����������룡",MB_ICONERROR);
			return;
		}
		theApp.AddOrModfiyRFiles(sName,sPath,m_bEnCode);
	}
	else
	{
		theApp.AddOrModfiyRFiles(sName,sPath,m_bEnCode);
	}
	EndDialog(0);
}
