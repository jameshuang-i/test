// SectionBar.cpp : implementation file
//

#include "stdafx.h"
#include "SuperConfig.h"
#include "SectionBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSectionBar dialog


CSectionBar::CSectionBar()
{
	m_szFloat = CSize(100, 500);
	m_nWidth=120;
	m_nHeight=0;
	m_nDockBarID = 0;
	m_nHoverItemID=-1;
	m_nOldHoverItemID=-1;
	m_bInPress=FALSE;
	m_bOldInPress=FALSE;
	m_bTracking=FALSE;
	m_nHtEdg=0;
	m_nSelItemID=-1;
	m_nOldSelItemID=-1;
	m_bNeedPaint=FALSE;

	LOGFONT lfSel={15, 0, 0, 0, FW_NORMAL, 0, 0, 0,DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS,DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, _T("����")};
	m_Font.CreateFontIndirect(&lfSel);
}

CSectionBar:: ~CSectionBar()
{

}

BOOL CSectionBar::Create(CWnd* pParentWnd,DWORD dwStyle,UINT nID)
{
	ASSERT_VALID(pParentWnd);   // must have a parent
	ASSERT (!((dwStyle & CBRS_SIZE_FIXED) && (dwStyle & CBRS_SIZE_DYNAMIC)));
	
	// save the style
	m_dwStyle = (dwStyle & CBRS_ALL);
	dwStyle &= ~CBRS_ALL;
	dwStyle |= WS_CLIPCHILDREN; // prevents flashing

	//register windowsclass
	WNDCLASS wndcls;
    HINSTANCE hInst = AfxGetInstanceHandle();
    if (!(::GetClassInfo(hInst, SECTIONBAR_WINDCLASSNAME, &wndcls)))
    {
        wndcls.style            = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
        wndcls.lpfnWndProc      = ::DefWindowProc;
        wndcls.cbClsExtra       = wndcls.cbWndExtra = 0;
        wndcls.hInstance        = hInst;
        wndcls.hIcon            = NULL;
        wndcls.hCursor          = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
        wndcls.hbrBackground    = (HBRUSH) (COLOR_BTNFACE+1);
        wndcls.lpszMenuName     = NULL;
        wndcls.lpszClassName    = SECTIONBAR_WINDCLASSNAME;
        if (!AfxRegisterClass(&wndcls))
        {
            AfxThrowResourceException();
            return FALSE;
        }
    }
	// create the HWND
	if (!CWnd::Create(SECTIONBAR_WINDCLASSNAME, _T("��ʽ��"), dwStyle, CRect(0,0,0,0), pParentWnd, nID))
		return FALSE;
	
	return TRUE;
}

CSize CSectionBar::CalcFixedLayout(BOOL bStretch, BOOL bHorz)
{
	if (bStretch) // the bar is stretched (is not the child of a dockbar)
		return CSize(m_nWidth,32767);
	else
	{
		CRect szDockBar;
		m_pDockSite->GetClientRect(szDockBar);
		return CSize(m_nWidth,szDockBar.Height());
	}
}

CSize CSectionBar::CalcDynamicLayout(int nLength, DWORD dwMode)
{
	if (dwMode & (LM_HORZDOCK | LM_VERTDOCK)) // docked ?
        return CControlBar::CalcDynamicLayout(nLength, dwMode);
	
    if (dwMode & LM_MRUWIDTH) return m_szFloat;
    if (dwMode & LM_COMMIT) return m_szFloat; // already committed
	
	if(dwMode&LM_LENGTHY)
		m_szFloat.cy=nLength;
	else
	{
		m_szFloat.cx=nLength;
		m_nWidth=nLength;
	}

	return m_szFloat;
}

BOOL CSectionBar::IsFloating() const
{
    return !(m_nDockBarID == AFX_IDW_DOCKBAR_TOP || m_nDockBarID == AFX_IDW_DOCKBAR_BOTTOM || 
		m_nDockBarID == AFX_IDW_DOCKBAR_LEFT || m_nDockBarID == AFX_IDW_DOCKBAR_RIGHT);
}

void CSectionBar::ShowTrackInvert()
{
    ASSERT(m_bTracking);
	
    CRect rc,rcFrame;
    GetWindowRect(rc);
    m_pDockSite->GetWindowRect(rcFrame);
    
	if(m_nHtEdg==HTLEFT)
		rc.right=rc.left+3;
	else
		rc.left=rc.right-3;
		
    int nOfs = m_nTrackPosOld - m_nTrackEdgeOfs;
    nOfs -= rc.CenterPoint().x;
    rc.OffsetRect(nOfs,0);
    rc.OffsetRect(-rcFrame.TopLeft());
	
    CDC *pDC = m_pDockSite->GetDCEx(NULL,DCX_WINDOW | DCX_CACHE | DCX_LOCKWINDOWUPDATE);
    CBrush* pBrush = CDC::GetHalftoneBrush();
    CBrush* pBrushOld = pDC->SelectObject(pBrush);
	
    pDC->PatBlt(rc.left, rc.top, rc.Width(), rc.Height(), PATINVERT);
    
    pDC->SelectObject(pBrushOld);
    m_pDockSite->ReleaseDC(pDC);
}

void CSectionBar::UpdateTrackSize(CPoint& point)
{
    ASSERT(!IsFloating());
	
    int nTrackPos = point.x;
    int nDelta = nTrackPos - m_nTrackPosOld;
	
    if (nDelta == 0)
        return; // no pos change
	
    ShowTrackInvert();// erase tracker
	
    m_nTrackPosOld = nTrackPos;
    
    switch (m_nHtEdg)
    {
    case HTLEFT:    m_nWidth-=nDelta; break;
    case HTRIGHT:   m_nWidth+=nDelta; break;
    }
	ShowTrackInvert(); // redraw tracker at new pos
}

int CSectionBar::InsertItem(CString sTitle, int nIndex)
{
	if(nIndex==-1)
		nIndex=m_aItems.GetSize();
	
	SectionBarItem* pItem=new SectionBarItem;
	pItem->sTitle=sTitle;
	m_aItems.InsertAt(nIndex,pItem);
	CalcLayout();
	m_bNeedPaint=TRUE;

	return nIndex;
}


void CSectionBar::RemoveAll()
{
	int nCount=m_aItems.GetSize();
	for(int i=0; i< nCount; i++)
		delete m_aItems[i];
	m_aItems.RemoveAll();
	m_nSelItemID=m_nOldSelItemID=m_nHoverItemID=-1;
	CalcLayout();
	m_bNeedPaint=TRUE;
}

void CSectionBar::CalcLayout()
{
	CRect szClient;
	GetClientRect(szClient);

	int nWidth=szClient.Width();
	UINT nHeight=0;
	int nCount=m_aItems.GetSize();
	
	for(int i=0;i<nCount;i++)
	{
		SectionBarItem* pItem=m_aItems.GetAt(i);
		pItem->rect.SetRect(0,nHeight,nWidth,nHeight+20);
		nHeight+=20;
	}	
	m_nHeight=nHeight;
	
	if(nHeight>(UINT)szClient.Height())
	{
		int nScrollMax=(nHeight-szClient.Height())/SECTIONBAR_SCROLLINTERVAL;
		SetScrollRange(SB_VERT,0,nScrollMax);
	}
	else
		SetScrollRange(SB_VERT,0,0);
}

BOOL CSectionBar::NotifyParent(UINT code, int nItem)
{
	CSECTIONBAR_NMHDR nmh;
	memset(&nmh,0,sizeof(CSECTIONBAR_NMHDR));
	nmh.hdr.hwndFrom = GetSafeHwnd();
	nmh.hdr.idFrom = GetDlgCtrlID();
	nmh.hdr.code=code;
	//SectionBarItem* pItem=m_aItems.GetAt(nItem);
	_tcscpy(nmh.pszTitle,m_aItems[nItem]->sTitle);
	//nmh.lpszTitle=pItem->sTitle;
	
	return (BOOL)GetParent()->SendMessage(WM_NOTIFY,GetDlgCtrlID(),(LPARAM)&nmh);
}

BEGIN_MESSAGE_MAP(CSectionBar, CControlBar)
	//{{AFX_MSG_MAP(CSectionBar)
	ON_WM_PAINT()
	ON_WM_NCPAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_LBUTTONDOWN()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONUP()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_SIZE()
	ON_WM_VSCROLL()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSectionBar message handlers

void CSectionBar::OnUpdateCmdUI(CFrameWnd* pTarget,BOOL bDisableIfNoHndler)
{
    UNUSED_ALWAYS(bDisableIfNoHndler);
    UNUSED_ALWAYS(pTarget);
	
	if(m_bNeedPaint)
		Invalidate();
	
	m_bInPress=(::GetKeyState(VK_LBUTTON) < 0);

	if(m_nHoverItemID>=0 || m_nOldHoverItemID>=0)
	{
		if( (m_nHoverItemID==SECTIONBAR_ITEMCLOSE && m_nOldHoverItemID!=SECTIONBAR_ITEMCLOSE) ||
			(m_nHoverItemID!=SECTIONBAR_ITEMCLOSE && m_nOldHoverItemID==SECTIONBAR_ITEMCLOSE) ||
			(m_nHoverItemID==SECTIONBAR_ITEMCLOSE && m_nOldHoverItemID==SECTIONBAR_ITEMCLOSE && m_bInPress!=m_bOldInPress) )
			SendMessage(WM_NCPAINT);
		
		if(m_bInPress!=m_bOldInPress || m_nSelItemID!=m_nOldSelItemID)
			Invalidate();
	}
	
	m_bOldInPress=m_bInPress;
	m_nOldSelItemID=m_nSelItemID;
	m_nOldHoverItemID=m_nHoverItemID;
}

void CSectionBar::OnPaint() 
{
	m_bNeedPaint=FALSE;
	CPaintDC dc(this); // device context for painting

	CRect szClient;
    GetClientRect(szClient);
	
	CDC mdc;
    mdc.CreateCompatibleDC(&dc);
    
	CFont* pFontOld=mdc.SelectObject(&m_Font);

    CBitmap bm;
    bm.CreateCompatibleBitmap(&dc, szClient.Width(),m_nHeight);
    CBitmap* pOldBm = mdc.SelectObject(&bm);
	
	// erase the NC background
    mdc.FillRect(CRect(szClient.left,szClient.top,szClient.Width(),m_nHeight), CBrush::FromHandle((HBRUSH) GetClassLong(m_hWnd, GCL_HBRBACKGROUND)));

	int nPrevBkMode = mdc.SetBkMode(TRANSPARENT);

	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		SectionBarItem* pItem=m_aItems.GetAt(i);
		if(m_nSelItemID==i || (m_nHoverItemID==i && m_bInPress))
			mdc.Draw3dRect(pItem->rect, ::GetSysColor(COLOR_BTNSHADOW),::GetSysColor(COLOR_BTNHIGHLIGHT));
		else
			mdc.Draw3dRect(pItem->rect, ::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW));
		
		if(m_nSelItemID==i)
		{
			CRect rc=pItem->rect;
			rc.DeflateRect(1,1,2,2);
			mdc.FillRect(rc,&CBrush::CBrush(::GetSysColor(COLOR_INFOBK)));
		}
		mdc.TextOut(pItem->rect.left+2, pItem->rect.top+1, pItem->sTitle);	
	}

	mdc.SetBkMode(nPrevBkMode);

	SCROLLINFO si;
	GetScrollInfo(SB_VERT,&si);
	//dc.SetViewportOrg(0,-si.nPos*SECTIONBAR_SCROLLINTERVAL);
    dc.BitBlt(0, 0, szClient.Width(), szClient.Height(), &mdc, 0,si.nPos*SECTIONBAR_SCROLLINTERVAL , SRCCOPY);
	
    ReleaseDC(&dc);
    mdc.SelectObject(pOldBm);
    bm.DeleteObject();
    mdc.DeleteDC();

	
}

void CSectionBar::OnNcPaint()
{
	CWindowDC dc(this);
	
	if(!IsFloating())
	{
		CRect rcClient, rcBar;
		GetClientRect(rcClient);
		ClientToScreen(rcClient);
		GetWindowRect(rcBar);
		rcClient.OffsetRect(-rcBar.TopLeft());
		rcBar.OffsetRect(-rcBar.TopLeft());

		CDC mdc;
		mdc.CreateCompatibleDC(&dc);
		
		CBitmap bm;
		bm.CreateCompatibleBitmap(&dc, rcBar.Width(), rcBar.Height());
		CBitmap* pOldBm = mdc.SelectObject(&bm);
		
		// draw borders in non-client area
		CRect rcDraw = rcBar;
		//DrawBorders(&mdc, rcDraw);
		
		// erase the NC background
		mdc.FillRect(rcDraw, CBrush::FromHandle((HBRUSH) GetClassLong(m_hWnd, GCL_HBRBACKGROUND)));
		
		// paint the sizing edges
		/*
		if (m_nDockBarID==AFX_IDW_DOCKBAR_LEFT)
		{
			CRect rcEdge=CRect(rcDraw); 
			rcEdge.left=rcEdge.right-3;
			mdc.Draw3dRect(rcEdge, ::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW));
		}
		else if(m_nDockBarID==AFX_IDW_DOCKBAR_RIGHT)
		{
			CRect rcEdge=CRect(rcDraw);
			rcEdge.right=rcEdge.left+3;
			mdc.Draw3dRect(rcEdge, ::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW));
		}
		*/

		CRect rcGripper = rcDraw;
		rcGripper.top += 6;
		rcGripper.bottom = rcGripper.top + 3;
		rcGripper.right = rcGripper.Width()-20;
		mdc.Draw3dRect(rcGripper, ::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW));
		rcGripper.OffsetRect(0,3);
		mdc.Draw3dRect(rcGripper, ::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW));
		
		CRect rcClose = rcDraw;
		rcClose.top+=3; rcClose.bottom=rcClose.top+10; rcClose.right-=5; rcClose.left=rcClose.right-10;

		if (m_nHoverItemID==SECTIONBAR_ITEMCLOSE)
		{
			if(m_bInPress)
				mdc.Draw3dRect(rcClose, ::GetSysColor(COLOR_BTNSHADOW),::GetSysColor(COLOR_BTNHIGHLIGHT));
			else
				mdc.Draw3dRect(rcClose, ::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW));
		}
		
		int nPrevBkMode = mdc.SetBkMode(TRANSPARENT);
		CFont font;
		int ppi = mdc.GetDeviceCaps(LOGPIXELSX);
		int pointsize = MulDiv(60, 96, ppi); // 6 points at 96 ppi
		font.CreatePointFont(pointsize, _T("Marlett"));
		CFont* oldfont = mdc.SelectObject(&font);
		mdc.TextOut(rcClose.left+2, rcClose.top+2, CString(_T("r"))); // x-like
		
		mdc.SelectObject(oldfont);
		mdc.SetBkMode(nPrevBkMode);
		
		dc.IntersectClipRect(rcBar);
		//Exclude ScrollBar Rgn
		int nMin,nMax;
		GetScrollRange(SB_VERT,&nMin,&nMax);
		if(nMax>0)
			if(m_nDockBarID==AFX_IDW_DOCKBAR_LEFT)
				rcClient.right+=16;
			else
				rcClient.left-=16;
		dc.ExcludeClipRect(rcClient);
		
		dc.BitBlt(0, 0, rcBar.Width(), rcBar.Height(), &mdc, 0, 0, SRCCOPY);
		ReleaseDC(&dc);
		
		mdc.SelectObject(pOldBm);
		bm.DeleteObject();
		mdc.DeleteDC();
	}
	CControlBar::OnNcPaint();
}

void CSectionBar::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp)
{
	CRect rc=CRect(&lpncsp->rgrc[0]);
	if(m_nDockBarID==AFX_IDW_DOCKBAR_LEFT)
		rc.DeflateRect(0, 15, 3, 0);
	else if(m_nDockBarID==AFX_IDW_DOCKBAR_RIGHT)
		rc.DeflateRect(3, 15, 0, 0);
	
	lpncsp->rgrc[0] = rc;
	CControlBar::OnNcCalcSize(bCalcValidRects,lpncsp);
		
}

void CSectionBar::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos)
{
    // force non-client recalc if moved or resized
    lpwndpos->flags |= SWP_FRAMECHANGED;
	
    CControlBar::OnWindowPosChanging(lpwndpos);
    // find on which side are we docked
    m_nDockBarID = GetParent()->GetDlgCtrlID();
}

UINT CSectionBar::OnNcHitTest(CPoint point)
{
	m_nHoverItemID=-1;
	
	UINT nRet=CControlBar::OnNcHitTest(point);
	if( nRet>HTCLIENT)
		return nRet;

    CRect rcBar;
    GetWindowRect(rcBar);
	if(!rcBar.PtInRect(point))
		return HTNOWHERE;
	
	if(!IsFloating())
	{
		if(m_nDockBarID==AFX_IDW_DOCKBAR_LEFT)
		{
			rcBar.left=rcBar.right-5;
			if(rcBar.PtInRect(point))
				return HTRIGHT;
		}
		if(m_nDockBarID==AFX_IDW_DOCKBAR_RIGHT)
		{
			rcBar.right=rcBar.left+5;
			if(rcBar.PtInRect(point))
				return HTLEFT;
		}

		rcBar.top+=3; rcBar.bottom=rcBar.top+10;
		rcBar.right-=5; rcBar.left=rcBar.right-10;
		//TRACE("%d %d || %d %d\n",rcBar.left,rcBar.top,point.x,point.y);
		if(rcBar.PtInRect(point))
		{
			m_nHoverItemID=SECTIONBAR_ITEMCLOSE;
			return HTCLOSE;
		}
	}
	
	int nCount=m_aItems.GetSize();
	ScreenToClient(&point);
	if(point.y>0)
	{
		SCROLLINFO si;
		GetScrollInfo(SB_VERT,&si);
		point.y+=si.nPos*SECTIONBAR_SCROLLINTERVAL;
		for(int i=0;i<nCount;i++)
		{
			CRect rc=m_aItems.GetAt(i)->rect;
			if(rc.PtInRect(point))
			{
				m_nHoverItemID=i;
				break;
			}
		}
	}
	return HTCLIENT;
}

void CSectionBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(m_nHoverItemID<0)
		CControlBar::OnLButtonDown(nFlags, point);
}

void CSectionBar::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (m_bTracking)
	{
		ShowTrackInvert(); // erase tracker
		m_bTracking = FALSE;
		ReleaseCapture();
		m_szFloat.cx=m_nWidth;
		m_pDockSite->DelayRecalcLayout();	
	}
	else
	{
		m_nSelItemID=m_nHoverItemID;
		if(m_nSelItemID!=m_nOldSelItemID)
			NotifyParent(SECTIONBAR_CLICK,m_nSelItemID);
	}

	CControlBar::OnLButtonUp(nFlags, point);
}

void CSectionBar::OnNcLButtonUp(UINT nHitTest, CPoint point) 
{
	if (nHitTest == HTCLOSE)
        m_pDockSite->ShowControlBar(this, FALSE, FALSE); // hide
	CControlBar::OnNcLButtonUp(nHitTest, point);
}

void CSectionBar::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	UNUSED_ALWAYS(point);
	
    if (m_bTracking)
        return;
	
    if (!IsFloating() && (nHitTest ==HTLEFT || nHitTest == HTRIGHT) )
	{
        SetCapture();
		m_nHtEdg=nHitTest;
		m_bTracking=TRUE;
		
		CRect szEdge;
		GetWindowRect(szEdge);

		if(nHitTest==HTLEFT)
			szEdge.right=szEdge.left+3;
		else
			szEdge.left=szEdge.right-3;
		
		m_nTrackPosOld=point.x;
		m_nTrackEdgeOfs=m_nTrackPosOld-szEdge.CenterPoint().x;
	}
	else if(nHitTest!=HTCLOSE)
		CControlBar::OnNcLButtonDown(nHitTest,point);
}

void CSectionBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_bTracking)
    {
        CPoint ptScreen = point;
        ClientToScreen(&ptScreen);
        UpdateTrackSize(ptScreen);
    }
	CControlBar::OnMouseMove(nFlags, point);
}


void CSectionBar::OnSize(UINT nType, int cx, int cy) 
{
	CControlBar::OnSize(nType, cx, cy);
	CalcLayout();
	m_bNeedPaint=TRUE;
}

void CSectionBar::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	SCROLLINFO scrollinfo; 
	
	GetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
	switch (nSBCode)  
	{  
	case SB_BOTTOM:  
		ScrollWindow(0,(scrollinfo.nPos-scrollinfo.nMax)*SECTIONBAR_SCROLLINTERVAL);  
		scrollinfo.nPos = scrollinfo.nMax;  
		SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
		break;  
	case SB_TOP:  
		ScrollWindow(0,(scrollinfo.nPos-scrollinfo.nMin)*SECTIONBAR_SCROLLINTERVAL);  
		scrollinfo.nPos = scrollinfo.nMin;
		SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);
		break;  
	case SB_LINEUP:  
		scrollinfo.nPos -= 1;  
		if (scrollinfo.nPos<scrollinfo.nMin) 
		{  
			scrollinfo.nPos = scrollinfo.nMin;  
			break;  
		}  
		SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
		ScrollWindow(0,SECTIONBAR_SCROLLINTERVAL);  
		break;  
	case SB_LINEDOWN:  
		scrollinfo.nPos += 1;  
		if (scrollinfo.nPos>scrollinfo.nMax)  
		{  
			scrollinfo.nPos = scrollinfo.nMax;  
			break;  
		}  
		SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
		ScrollWindow(0,-SECTIONBAR_SCROLLINTERVAL);  
		break;  
	case SB_PAGEUP:  
		scrollinfo.nPos -= 5;  
		if (scrollinfo.nPos <scrollinfo.nMin) 
		{  
			scrollinfo.nPos = scrollinfo.nMin;  
			break;  
		}  
		SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
		ScrollWindow(0,SECTIONBAR_SCROLLINTERVAL*5);  
		break;  
	case SB_PAGEDOWN:  
		scrollinfo.nPos += 5;  
		if (scrollinfo.nPos>scrollinfo.nMax)  
		{  
			scrollinfo.nPos = scrollinfo.nMax;  
			break;  
		}  
		SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
		ScrollWindow(0,-SECTIONBAR_SCROLLINTERVAL*5);  
		break;  
	case SB_ENDSCROLL:  
		// MessageBox("SB_ENDSCROLL");  
		break;  
	case SB_THUMBPOSITION:  
		// ScrollWindow(0,(scrollinfo.nPos-nPos)*10);  
		// scrollinfo.nPos = nPos;  
		// SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
		break;  
	case SB_THUMBTRACK:  
		ScrollWindow(0,(scrollinfo.nPos-nPos)*SECTIONBAR_SCROLLINTERVAL);  
		scrollinfo.nPos = nPos;  
		SetScrollInfo(SB_VERT,&scrollinfo,SIF_ALL);  
		break;  
	} 

	CControlBar::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CSectionBar::OnDestroy() 
{
	CControlBar::OnDestroy();
	RemoveAll();
}

int CSectionBar::SetItemSelect(CString sTitle)
{
	int nRet=-1;
	int nCount=m_aItems.GetSize();
	for(int i=0;i<nCount;i++)
	{
		SectionBarItem* pItem=m_aItems.GetAt(i);
		if(pItem->sTitle==sTitle)
		{
			m_nSelItemID=i;
			m_bNeedPaint=TRUE;
			nRet=i;
			break;
		}
	}
	return nRet;
}
