#if !defined(AFX_TABBAR_H__F25ACB34_FFF6_4225_8B0A_A578DDD83033__INCLUDED_)
#define AFX_TABBAR_H__F25ACB34_FFF6_4225_8B0A_A578DDD83033__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabBar.h : header file
//

#define TABBAR_ID 1003
#define TABBAR_WINDCLASSNAME	_T("TABBAR.WINDOWCLASS")
#define TABBAR_HEIGHT 24
#define TABBAR_ICONHEIGHT 16
#define TABBAR_LEFTEBTN 1001
#define TABBAR_RIGHTBTN 1002

#define TABBAR_CLICK				NM_CLICK
#define TABBAR_RCLICK				NM_RCLICK
#define TABBAR_DBLCLK				NM_DBLCLK

#define TABBAR_TIMER_DRAG	1

typedef struct _CTABBAR_NMHDR 
{
    NMHDR	hdr;
	DWORD	lpExtra;
} CTABBAR_NMHDR;


/////////////////////////////////////////////////////////////////////////////
// CTabBar CControlBar

class CTabBar : public CControlBar
{
// Construction
public:
	CTabBar(); 
	virtual ~CTabBar();
	BOOL Create(CWnd* pParentWnd,DWORD dwStyle= WS_CHILD|WS_VISIBLE|CBRS_TOP,UINT nID = TABBAR_ID);
	
	typedef struct _tagTabBarItem
	{
		CString		sTitle;
		CString		sTip;
		int			nIcon;
		CRect		rect;
		CRgn		rgn;
		DWORD		lpExtra;
		_tagTabBarItem()
		{
			sTitle=_T("");
			sTip=_T("");
			nIcon=iconNone;
			rect.SetRect(0,0,0,0);
			lpExtra=0;
			rgn.CreateRectRgn(0,0,0,0);
		}
	}TabBarItem;

	enum iconType {iconNone=0,iconLocal,iconLocal2,iconRemote,iconRemote2};
// Overrides
	//{{AFX_VIRTUAL(CTabBar)
	public:
	virtual void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler) {};
	virtual CSize CalcFixedLayout(BOOL bStretch, BOOL bHorz);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

private:
	CArray <TabBarItem*,TabBarItem*>	m_aItems;
	int		m_nSelectItem;
	int		m_nHoverItem;
	HICON	m_hIconLocal;
	HICON	m_hIconRemote;
	HICON	m_hIconLocal2;
	HICON	m_hIconRemote2;
	CFont	m_Font;
	int		m_nOffsetCount;
	int		m_nWidthShow;
	CRect	m_rectRightBtn;
	CRect	m_rectLeftBtn;
	BOOL	m_bTracing;
	int		m_nDrgSrc;
	CToolTipCtrl	m_ctrTip;
	HCURSOR	m_hCursorMove;
	CRgn	m_rgnTriangleLeft;
	CRgn	m_rgnTriangleRight;
	CRgn	m_rgnInsert;
// Dialog Data
	//{{AFX_DATA(CTabBar)
	//}}AFX_DATA

// Implementation
public:
	void SetShowIcon(DWORD lpExtra,iconType iconT);
	int	GetItemCount() {return m_aItems.GetSize();}
	int InsertItem(CString sText,CString sTip,iconType iconT=iconNone,DWORD lpExtra=NULL,int nIndex=-1);
	int RemoveItem(DWORD lpExtra);
	BOOL SetSelected(DWORD lpExtra);
	void SetText(DWORD lpExtra,CString sText);	
	void SetTip(DWORD lpExtra,CString sTip);	
private:
	void CalcItemSize(TabBarItem* pItem);
	void CalcLayout();
	int	 HitTest(CPoint pt);
	BOOL NotifyParent(UINT code, int nItem);
protected:
	//{{AFX_MSG(CTabBar)
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg LONG OnMouseLeave(WPARAM /*wParam*/, LPARAM /*lParam*/);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABBAR_H__F25ACB34_FFF6_4225_8B0A_A578DDD83033__INCLUDED_)
