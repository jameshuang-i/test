// SuperConfigView.cpp : implementation of the CSuperConfigView class
//

#include "stdafx.h"
#include "SuperConfig.h"

#include "SuperConfigDoc.h"
#include "CntrItem.h"
#include "SuperConfigView.h"

#include "MainFrm.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define DRAWBUFFERSIZE	10240
#define MAXSECTIONLENGTH	100

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigView

IMPLEMENT_DYNCREATE(CSuperConfigView, CRichEditView)

BEGIN_MESSAGE_MAP(CSuperConfigView, CRichEditView)
	//{{AFX_MSG_MAP(CSuperConfigView)
	ON_WM_DESTROY()
	ON_WM_CREATE()
	ON_NOTIFY(NM_CLICK, SECTIONBAR_ID, OnSectionClick)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_WM_PAINT()
	ON_COMMAND(ID_TOOL_FRESH, OnToolFresh)
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_VIEW_SYNCHIGHT, OnViewSynchight)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SYNCHIGHT, OnUpdateViewSynchight)
	ON_COMMAND(ID_TOOL_FORMAT, OnToolFormat)
	ON_COMMAND(ID_TOOL_RESTART, OnRestartServer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigView construction/destruction

CSuperConfigView::CSuperConfigView()
{
	m_bShowModified=FALSE;
	m_nCaretLine=-1;
	m_bCanPaint=TRUE;
	m_nCharHeight=16;
	m_pBuffer=new TCHAR[DRAWBUFFERSIZE];
	m_pSectionHeader=NULL;
	m_pKeyHeader=NULL;
	m_pValueHeader=NULL;
	m_pCommitHeader=NULL;
}

CSuperConfigView::~CSuperConfigView()
{
	int nCount=m_pArraySection.GetSize();
	for(int i=0; i<nCount; i++)
	{
		INISECTION* pSection = m_pArraySection.GetAt(i);
		delete pSection;
		pSection = NULL;
	}
	m_pArraySection.RemoveAll();
	delete [] m_pBuffer;

	COLORITEM* pItemNext=NULL;
	COLORITEM* pItemPre=NULL;

	pItemPre=m_pSectionHeader;
	while(pItemPre!=NULL)
	{
		pItemNext=pItemPre->next;
		delete pItemPre;
		pItemPre=pItemNext;
	}
	pItemPre=m_pValueHeader;
	while(pItemPre!=NULL)
	{
		pItemNext=pItemPre->next;
		delete pItemPre;
		pItemPre=pItemNext;
	}
	pItemPre=m_pKeyHeader;
	while(pItemPre!=NULL)
	{
		pItemNext=pItemPre->next;
		delete pItemPre;
		pItemPre=pItemNext;
	}
	pItemPre=m_pCommitHeader;
	while(pItemPre!=NULL)
	{
		pItemNext=pItemPre->next;
		delete pItemPre;
		pItemPre=pItemNext;
	}
}

BOOL CSuperConfigView::PreCreateWindow(CREATESTRUCT& cs)
{
/*	
	if (LoadLibraryA("RICHED20.DLL") == NULL)   
    {   
        AfxMessageBox(_T("Fail to load \"riched20.dll\"."),MB_OK | MB_ICONERROR);   
        PostMessage(WM_QUIT,0,0);   
        return FALSE;   
    }   
    m_strClass = RICHEDIT_CLASSA;   //for 2.0 class     
*/	
	return CRichEditView::PreCreateWindow(cs);
}

void CSuperConfigView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();

	SetMargins(CRect(720, 720, 720, 720));

	m_nWordWrap=WrapNone;
	WrapChanged();	

	LOGFONT lf;
	::GetObject(GetStockObject(SYSTEM_FONT), sizeof(LOGFONT), &lf);  
    lf.lfWeight = FW_THIN;	//FW_NORMAL;    //FW_THIN
	lf.lfHeight = 0xfffffff2;
    lf.lfCharSet = GB2312_CHARSET; //OEM_CHARSET; //EASTEUROPE_CHARSET; //BALTIC_CHARSET; //ANSI_CHARSET; //CHINESEBIG5_CHARSET; //ANSI_CHARSET; //DEFAULT_CHARSET;  
	lf.lfWidth=0x7fffffff;
    strcpy(lf.lfFaceName, _T("����"));     //Courier New Symbol Fixedsys
    m_font.CreateFontIndirect(&lf);    
    SetFont(&m_font);   
	
	SendMessage(EM_SETUNDOLIMIT, 1000, 0);   
    GetDocument()->m_bRTF = FALSE;      
	
    SendMessage(EM_SETTEXTMODE, TM_PLAINTEXT|TM_MULTILEVELUNDO|TM_MULTICODEPAGE, 0);   

	CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
	if(GetDocument()->m_sName.IsEmpty()) //new document
		pMainFrame->m_wndTabBar.InsertItem(GetDocument()->GetTitle(),GetDocument()->GetTitle(),CTabBar::iconLocal,(DWORD)GetParent());
	else
		pMainFrame->m_wndTabBar.InsertItem(GetDocument()->m_sName,GetDocument()->m_sTitle,GetDocument()->m_bLocal? CTabBar::iconLocal: CTabBar::iconRemote,(DWORD)GetParent());

	PraseSection();

	GetDocument()->SetModifiedFlag(FALSE);
}

void CSuperConfigView::OnDestroy()
{
   CRichEditView::OnDestroy();
   /* ����ᱨ��
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
   */
   CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
   pMainFrame->m_wndTabBar.RemoveItem((DWORD)GetParent());
}


/////////////////////////////////////////////////////////////////////////////
// CSuperConfigView diagnostics

#ifdef _DEBUG
void CSuperConfigView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CSuperConfigView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CSuperConfigDoc* CSuperConfigView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSuperConfigDoc)));
	return (CSuperConfigDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigView message handlers

void CSuperConfigView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{
	if(bActivate)
	{
		CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
		pMainFrame->m_wndTabBar.SetSelected((DWORD)GetParent());
	}
	CRichEditView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

int CSuperConfigView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CRichEditView::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}

void CSuperConfigView::OnSectionClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	CSECTIONBAR_NMHDR* pItem=(CSECTIONBAR_NMHDR*)pNMHDR;

	int nCount=m_pArraySection.GetSize();
	for(int i=0;i<nCount;i++)
	{
		INISECTION* pSection=m_pArraySection.GetAt(i);
		if(strcmp(pSection->lpszName,pItem->pszTitle)==0)
		{
			long nLine=GetRichEditCtrl().GetFirstVisibleLine();
			GetRichEditCtrl().LineScroll(pSection->nStartLine-nLine);
			long ncharpos=GetRichEditCtrl().LineIndex(pSection->nStartLine);
			GetRichEditCtrl().SetSel(ncharpos,ncharpos);
		}
	}
	*pResult=0;
}

void CSuperConfigView::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	int nLine=GetRichEditCtrl().LineFromChar(-1);
	if(nLine!=m_nCaretLine)
	{
		RECT rect;
		SendMessage(EM_GETRECT,0,(LPARAM)&rect);
		rect.left+=8;	rect.top+=5;
		int nLineIndex = GetRichEditCtrl().LineIndex(m_nCaretLine);
		CPoint ptPos = GetRichEditCtrl().GetCharPos(nLineIndex);
		rect.top=ptPos.y;	rect.bottom=rect.top+m_nCharHeight;
		InvalidateRect(&rect,FALSE);
		nLineIndex = GetRichEditCtrl().LineIndex(nLine);
		ptPos = GetRichEditCtrl().GetCharPos(nLineIndex);
		rect.top=ptPos.y;	rect.bottom=rect.top+m_nCharHeight;
		InvalidateRect(&rect,FALSE);
		UpdateWindow();
	}

	if(GetDocument()->IsModified()!=m_bShowModified)
	{
		m_bShowModified=GetDocument()->IsModified();

		CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
		if(m_bShowModified)
			if(GetDocument()->m_bLocal)
				pMainFrame->m_wndTabBar.SetShowIcon((DWORD)GetParent(),CTabBar::iconLocal2);
			else
				pMainFrame->m_wndTabBar.SetShowIcon((DWORD)GetParent(),CTabBar::iconRemote2);
		else
			if(GetDocument()->m_bLocal)
				pMainFrame->m_wndTabBar.SetShowIcon((DWORD)GetParent(),CTabBar::iconLocal);
			else
				pMainFrame->m_wndTabBar.SetShowIcon((DWORD)GetParent(),CTabBar::iconRemote);	
	}
}

void CSuperConfigView::OnPaint() 
{
	CClientDC dc(this);
	CFont* oldFont=dc.SelectObject(&m_font);
 
	Default();
	
	RECT rect;
	SendMessage(EM_GETRECT,0,(LPARAM)&rect);
	rect.left+=8;	rect.top+=2;
	//CPaintDC dc(this);	

	if(g_bSyncHigh)
	{	
		TEXTRANGE txtRange;
		int nPos=SendMessage(EM_CHARFROMPOS,0,(LPARAM)&rect);
		int nLine=SendMessage(EM_LINEFROMCHAR,nPos,0);
		txtRange.chrg.cpMin=SendMessage(EM_LINEINDEX,nLine,0);
		txtRange.chrg.cpMax = SendMessage(EM_CHARFROMPOS,0,(LPARAM)&rect.right);
		txtRange.lpstrText = m_pBuffer;
		DWORD BufferSize = SendMessage(EM_GETTEXTRANGE,0,(LPARAM)&txtRange);
		
		if(PraseINI(m_pBuffer,txtRange.chrg.cpMin))
		{
			COLORITEM* pItem;			
			COLORREF oldClr;
			//CClientDC dc(this);
			
			dc.SetBkMode(TRANSPARENT);
			HRGN hRgn = CreateRectRgn(rect.left,rect.top,rect.right,rect.bottom);
			HRGN hOldRgn = (HRGN)dc.SelectObject(hRgn);
			
			
			pItem=m_pSectionHeader;
			oldClr=dc.SetTextColor(RGB(226,175,24));
			while(pItem!=NULL)
			{
				if(pItem->nLength==0)
					break;
				dc.TextOut(pItem->x,pItem->y+2,&m_pBuffer[pItem->nStart],pItem->nLength);
				pItem=pItem->next;
			}
			pItem=m_pCommitHeader;
			dc.SetTextColor(RGB(128,128,128));
			while(pItem!=NULL)
			{
				if(pItem->nLength==0)
					break;
				dc.TextOut(pItem->x,pItem->y+2,&m_pBuffer[pItem->nStart],pItem->nLength);
				pItem=pItem->next;
			}
			pItem=m_pValueHeader;
			dc.SetTextColor(RGB(0,0,200));
			while(pItem!=NULL)
			{
				if(pItem->nLength==0)
					break;
				dc.TextOut(pItem->x,pItem->y+2,&m_pBuffer[pItem->nStart],pItem->nLength);
				pItem=pItem->next;
			}
			pItem=m_pKeyHeader;
			dc.SetTextColor(RGB(255,0,0));
			while(pItem!=NULL)
			{
				if(pItem->nLength==0)
					break;
				dc.TextOut(pItem->x,pItem->y+2,&m_pBuffer[pItem->nStart],pItem->nLength);
				pItem=pItem->next;
			}
			
			dc.SetTextColor(oldClr);
			dc.SelectObject(hOldRgn);
			DeleteObject(hRgn);
		}

	}
	dc.SelectObject(oldFont);
	HideCaret();
	if(m_bCanPaint)
	{
		dc.IntersectClipRect(&rect);
		int nLine=GetRichEditCtrl().LineFromChar(-1);
		int nLineFirst=GetRichEditCtrl().GetFirstVisibleLine();
		long nLineLast = GetRichEditCtrl().LineFromChar(GetRichEditCtrl().SendMessage(EM_CHARFROMPOS, 0, (LPARAM)&rect.right));	
		
		if (m_nCaretLine >= nLineFirst && m_nCaretLine <= nLineLast)
		{
			m_bCanPaint = FALSE;
			int nLineIndex = GetRichEditCtrl().LineIndex(m_nCaretLine);
			CPoint ptPos = GetRichEditCtrl().GetCharPos(nLineIndex);
			rect.top=ptPos.y;
			rect.bottom=rect.top+m_nCharHeight;
			InvalidateRect(&rect,TRUE);
			UpdateWindow();
			m_bCanPaint = TRUE;
		}
		
		if (nLine >= nLineFirst && nLine <=nLineLast)
		{
			int nLineIndex = GetRichEditCtrl().LineIndex(nLine);
			CPoint ptPos = GetRichEditCtrl().GetCharPos(nLineIndex);
			rect.top=ptPos.y;
			rect.bottom=rect.top+m_nCharHeight;
			CDC dcMem;
			dcMem.CreateCompatibleDC(&dc);
			CBitmap bmp;
			bmp.CreateCompatibleBitmap(&dc, rect.right-rect.left, rect.bottom-rect.top);
			CBitmap* pSaveBmp = dcMem.SelectObject(&bmp);
			CBrush br(RGB(59,18,2));//RGB(0, 0, 100)
			dcMem.FillRect(CRect(0, 0, rect.right-rect.left, rect.bottom-rect.top), &br);
			dcMem.BitBlt(0, 0, rect.right-rect.left, rect.bottom-rect.top, &dc, rect.left, rect.top, SRCINVERT);
			dc.BitBlt(rect.left, rect.top, rect.right-rect.left, rect.bottom-rect.top, &dcMem, 0, 0, SRCCOPY);
			dcMem.SelectObject(pSaveBmp);
		}
		
		if(m_nCaretLine!=nLine)
			SetSectionBar(nLine);
		m_nCaretLine = nLine;
	}

    ShowCaret();

}

void CSuperConfigView::SetSectionBar(int nLine)
{
	int nCount=m_pArraySection.GetSize();
	CString sText;
	
	for(int i=0;i<nCount;i++)
	{
		INISECTION* pSection=m_pArraySection.GetAt(i);
		if(nLine>=pSection->nStartLine)
			sText=pSection->lpszName;
		else if(nLine<pSection->nStartLine)
			break;
	}
	CChildFrame *pChildFrame=(CChildFrame*)GetParent();
	pChildFrame->m_wndFormatBar.SetItemSelect(sText);
}

void CSuperConfigView::OnToolFresh() 
{
	PraseSection();
}

void CSuperConfigView::OnRestartServer()
{
	if(GetDocument()->m_sServer=="")
	{
		AfxMessageBox("ֻ�е�ǰ�򿪵��ļ�����Զ�̷������� ����ʹ�ô˹��ܣ�",MB_ICONERROR);
		return;
	}
	char sCmd[1024];
	sprintf(sCmd,"restart.vbs %s %s %s",GetDocument()->m_sServer,GetDocument()->m_sUsr,GetDocument()->m_sPwd);
	system(sCmd);
}

void CSuperConfigView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	CMenu popmenu;
	CPoint ptScreen = point;
	
	popmenu.CreatePopupMenu();
	popmenu.AppendMenu(0, ID_EDIT_UNDO, "����(&U)");
	popmenu.AppendMenu(0, MF_SEPARATOR);
	popmenu.AppendMenu(0, ID_EDIT_CUT, "����(&X)");
	popmenu.AppendMenu(0, ID_EDIT_COPY, "����(&C)");
	popmenu.AppendMenu(0, ID_EDIT_PASTE, "ճ��(&P)");
	popmenu.AppendMenu(0, MF_SEPARATOR);
	popmenu.AppendMenu(0, ID_EDIT_FIND, "����(&S)...");
	popmenu.AppendMenu(0, ID_EDIT_REPLACE, "�滻(&R)...");
	popmenu.AppendMenu(0, MF_SEPARATOR);
	popmenu.AppendMenu(0, ID_TOOL_FRESH, "ˢ��(&R)");
	popmenu.AppendMenu(0, ID_TOOL_COMMIT, "ע��/ȥע��(&M)");
	popmenu.AppendMenu(0, ID_TOOL_FORMAT, "��ʾ��ʽ��(&F)");
	popmenu.AppendMenu(0, ID_TOOL_RESTART, "����ƽ̨(&R)");

	UINT nUndo=(GetRichEditCtrl().CanUndo() ? 0 : MF_GRAYED );
	popmenu.EnableMenuItem(ID_EDIT_UNDO, MF_BYCOMMAND|nUndo);
	UINT nSel=((GetRichEditCtrl().GetSelectionType()!=SEL_EMPTY) ? 0 : MF_GRAYED) ;
	popmenu.EnableMenuItem(ID_EDIT_CUT, MF_BYCOMMAND|nSel);
	popmenu.EnableMenuItem(ID_EDIT_COPY, MF_BYCOMMAND|nSel);
	UINT nPaste=(CanPaste() ? 0 : MF_GRAYED) ;
	popmenu.EnableMenuItem(ID_EDIT_PASTE, MF_BYCOMMAND|nPaste);
	
	ClientToScreen (&ptScreen);
	popmenu.TrackPopupMenu(TPM_RIGHTBUTTON, ptScreen.x, ptScreen.y, this);
	popmenu.DestroyMenu();
	
	CRichEditView::OnRButtonUp(nFlags, point);
}

void CSuperConfigView::PraseSection()
{
	int i,j,nCount=m_pArraySection.GetSize(),nLineCount = GetRichEditCtrl().GetLineCount();
	TCHAR buffer[1024];

	for(i=0; i<nCount; i++)
	{
		INISECTION *pSection = (INISECTION*)m_pArraySection.GetAt(i);
		delete pSection;
		pSection = NULL;
	}
	m_pArraySection.RemoveAll();
	
	for (i=0;i < nLineCount;i++)
	{
		int nLineLength=GetRichEditCtrl().GetLine(i,buffer,1000);
		buffer[nLineLength]='\0';
		int nStart=0;
		for(j=0;j<nLineLength;j++)
		{
			if(buffer[j]=='[')
				nStart=j+1;
			else if(buffer[j]==']' && nStart>0)
			{
				INISECTION *pSection =new INISECTION();
				strncpy(pSection->lpszName,&buffer[nStart],j-nStart);
				pSection->lpszName[j-nStart]='\0';
				pSection->nStartLine=i;
				m_pArraySection.Add(pSection);
				nStart=0;
			}
			else if(buffer[j]>32 && nStart==0)
				break;
		}
	}

	CChildFrame* pChildFrame=(CChildFrame*)GetParent();
	pChildFrame->m_wndFormatBar.RemoveAll();
	nCount=m_pArraySection.GetSize();
	for(i=0; i<nCount; i++)
	{
		INISECTION *pSection = (INISECTION*)m_pArraySection.GetAt(i);
		pChildFrame->m_wndFormatBar.InsertItem(pSection->lpszName);				
	}

}

void CSuperConfigView::OnViewSynchight() 
{
	int nret=GetProfileInt("GENERAL","IsSyncHightLight",1);
	if(nret)
	{
		WriteProfileString("GENERAL","IsSyncHightLight","0");
		g_bSyncHigh=FALSE;
	}
	else
	{
		WriteProfileString("GENERAL","IsSyncHightLight","1");
		g_bSyncHigh=TRUE;
	}
	Invalidate();
}

void CSuperConfigView::OnUpdateViewSynchight(CCmdUI* pCmdUI) 
{
	if(g_bSyncHigh)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

BOOL CSuperConfigView::PraseINI(TCHAR *pbuffer,long FirstCharIndex)
{
	TCHAR *pSymbolStart=NULL,*pPtr = pbuffer;
	TCHAR SectionName[MAXSECTIONLENGTH];
	CPoint pt;

	if(m_pCommitHeader!=NULL)
		m_pCommitHeader->nLength=0;
	if(m_pSectionHeader!=NULL)
		m_pSectionHeader->nLength=0;
	if(m_pKeyHeader!=NULL)
		m_pKeyHeader->nLength=0;
	if(m_pValueHeader!=NULL)
		m_pValueHeader->nLength=0;
	
	while (*pPtr != 0) 
	{
		//��ע��
		if (*pPtr==';' || *pPtr=='#')
		{
			do 
			{
				while(*pPtr==9)
					pPtr++;
				pSymbolStart = pPtr++;
				while(*pPtr!=0 && *pPtr!='\r' && *pPtr!='\n')
				{
					pPtr++;
				}
				if(pPtr-pSymbolStart>1)
				{
					pt=GetRichEditCtrl().GetCharPos(pSymbolStart-pbuffer+FirstCharIndex);
					COLORITEM* ct=(COLORITEM*)GetColorItem(&m_pCommitHeader);
					ct->x=pt.x;	ct->y=pt.y;
					ct->nStart=pSymbolStart-pbuffer;
					ct->nLength=pPtr-pSymbolStart;
				}
			} while (*pPtr==9);
			
		}
		//��ע��
		else if((*pPtr=='/' && *(pPtr+1)=='*'))
		{
			do 
			{
				while(*pPtr==9)
					pPtr++;
				pSymbolStart = pPtr++;
				while(*pPtr!=0 && *pPtr!='\r' && *pPtr!='\n' )
				{
					if(*pPtr=='*' && *(pPtr+1)=='/')
					{
						pPtr++;
						break;
					}
					else
						pPtr++;
				}
				if(pPtr-pSymbolStart>1)
				{
					pt=GetRichEditCtrl().GetCharPos(pSymbolStart-pbuffer+FirstCharIndex);
					COLORITEM* ct=(COLORITEM*)GetColorItem(&m_pCommitHeader);
					ct->x=pt.x;	ct->y=pt.y;
					ct->nStart=pSymbolStart-pbuffer;
					ct->nLength=pPtr-pSymbolStart;
				}
			} while (*pPtr==9);
			
		}
		//��ͷ
		else if (*pPtr=='[')
		{
			pSymbolStart = pPtr++;
			while(*pPtr!=0 && *pPtr!='\r' && *pPtr!='\n')
				if(*pPtr++==']')
					break;
			if(pPtr-pSymbolStart>2 && *(pPtr-1)==']')
			{
				int nsize=pPtr-pSymbolStart-1>MAXSECTIONLENGTH? MAXSECTIONLENGTH:pPtr-pSymbolStart-2;
				strncpy(SectionName,pSymbolStart+1,nsize);
				SectionName[nsize]='\0';
				pt=GetRichEditCtrl().GetCharPos(pSymbolStart-pbuffer+FirstCharIndex);
				COLORITEM* ct=(COLORITEM*)GetColorItem(&m_pSectionHeader);
				ct->x=pt.x;	ct->y=pt.y;
				ct->nStart=pSymbolStart-pbuffer;
				ct->nLength=pPtr-pSymbolStart;
			}
		}
		//ֵ
		else if (*pPtr=='=')
		{
			do 
			{
				while(*pPtr==9)
					pPtr++;
				if(*pPtr=='=')
					pSymbolStart = ++pPtr;
				else
					pSymbolStart = pPtr++;
				while (*pPtr!=0 && *pPtr!='\r' && *pPtr!='\n')
				{
					if (*pPtr==';' || *pPtr=='#' || (*pPtr=='/' && *(pPtr+1)=='*'))
						break;
					else
						pPtr++;
				}
				if(pPtr-pSymbolStart>1)
				{
					pt=GetRichEditCtrl().GetCharPos(pSymbolStart-pbuffer+FirstCharIndex);
					COLORITEM* ct=(COLORITEM*)GetColorItem(&m_pValueHeader);
					ct->x=pt.x;	ct->y=pt.y;
					ct->nStart=pSymbolStart-pbuffer;
					ct->nLength=pPtr-pSymbolStart;
				}
				
			} while (*pPtr==9);
		
		}
		//�ؼ�����
		else if (*pPtr>32)
		{
			pSymbolStart = pPtr;
			BOOL bIsKey=FALSE;
			int nIndex=0;
			TCHAR lpszKeyName[MAXSECTIONLENGTH];
			
			lpszKeyName[nIndex++]=*(pPtr++);
			while (*pPtr != 0 && *pPtr != '\r' && *pPtr!='\n' && *pPtr!=';' && (*pPtr!='/' && *(pPtr+1)!='*') && nIndex<MAXSECTIONLENGTH)
			{
				lpszKeyName[nIndex++]=*(pPtr++);
				if(*pPtr=='=')
				{
					lpszKeyName[nIndex]='\0';
					for(int i=nIndex-1;i>=0 && lpszKeyName[i]<=32;i--)
						lpszKeyName[i]='\0';
					if(SectionName[0]==0 && m_pArraySection.GetSize()>0)
					{
						int nLine=SendMessage(EM_LINEFROMCHAR,pPtr-pbuffer+FirstCharIndex,0);
						int nCount=m_pArraySection.GetSize();
						for(int i=0;i<nCount;i++)
						{
							INISECTION* pSection=m_pArraySection.GetAt(i);
							if(nLine>=pSection->nStartLine)
								strcpy(SectionName,pSection->lpszName);
							else if(nLine<pSection->nStartLine)
								break;
						}
					}
					if(theApp.IsKeyWordExist(GetDocument()->m_sName,SectionName,lpszKeyName))
					{
						pt=GetRichEditCtrl().GetCharPos(pSymbolStart-pbuffer+FirstCharIndex);
						COLORITEM* ct=(COLORITEM*)GetColorItem(&m_pKeyHeader);
						ct->x=pt.x;	ct->y=pt.y;
						ct->nStart=pSymbolStart-pbuffer;
						ct->nLength=pPtr-pSymbolStart;
					}
					break;
				}
			}
		}
		else
			pPtr++;
	}

	return TRUE;
}


DWORD CSuperConfigView::GetColorItem(_COLORITEM** pHead)
{
	
	COLORITEM* pItem=*pHead;
	COLORITEM* pPreItem=pItem;

	while(pItem!=NULL)
	{
		if(pItem->nLength==0)
			break;
		pPreItem=pItem;
		pItem=pItem->next;
	}

	if(pItem==NULL)
	{
		pItem=new COLORITEM;
		pItem->nLength=0;
		pItem->next=NULL;
		if(pPreItem==NULL)
			*pHead=pItem;
		else
			pPreItem->next=pItem;
	}
	else
		if(pItem->next!=NULL)
			pItem->next->nLength=0;
	
	return (DWORD)pItem;
}

void CSuperConfigView::OnToolFormat() 
{
	CString strContent;
	TCHAR* lpBuffer;
	TCHAR* lpDest;
	int nIndex=0;
	BOOL bNewLine=FALSE;

	if(AfxMessageBox("�Ƿ�ȷ��Ҫ���ļ����ݽ��и�ʽ����ʾ��\n\nע�⣺�˹��̲��ܻ��ˣ�",MB_ICONQUESTION+MB_YESNO)==IDNO)
 		return;
	
	GetWindowText(strContent);

	lpDest=new TCHAR[strContent.GetLength()+GetRichEditCtrl().GetLineCount()];
	lpBuffer=strContent.GetBuffer(strContent.GetLength());
	while(*lpBuffer!='\0')
	{
		if(*lpBuffer=='\n' && bNewLine==FALSE)
		{
			lpDest[nIndex++]=*lpBuffer;
			bNewLine=TRUE;
		}
		else if(bNewLine)
		{
			if(*lpBuffer>32)
			{
				if(*lpBuffer=='[')
					lpDest[nIndex++]='\n';
				lpDest[nIndex++]=*lpBuffer;
				bNewLine=FALSE;
			}
		}
		else
			lpDest[nIndex++]=*lpBuffer;

		lpBuffer++;
	}
	lpDest[nIndex]='\0';
	strContent.ReleaseBuffer();
	SetWindowText(lpDest);	
	delete []lpDest;
	PraseSection();
}
