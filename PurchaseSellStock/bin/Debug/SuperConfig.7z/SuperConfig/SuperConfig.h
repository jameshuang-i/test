// SuperConfig.h : main header file for the SUPERCONFIG application
//

#if !defined(AFX_SUPERCONFIG_H__E585CAB4_BE5E_43F2_B4C6_AFEB05AC9183__INCLUDED_)
#define AFX_SUPERCONFIG_H__E585CAB4_BE5E_43F2_B4C6_AFEB05AC9183__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSuperConfigApp:
// See SuperConfig.cpp for the implementation of this class
//

class CSuperConfigApp : public CWinApp
{
public:
	CString GetTempFileName();
	CSuperConfigApp();
	
	CString GetFtpPwd(CString strPWD);
	CString GetFtpUsr(CString strIP);
	CString GetFtpName(int nIndex);
	int GetFtpsCount();
	void AddorModifyFtp(CString strIP,CString strUSR,CString strPWD);
	BOOL DelRFiles(CString strLocalName);
	BOOL AddOrModfiyRFiles(CString strLocalName,CString strRemotePathFileName,BOOL bEnCode);
	BOOL GetRFilesEncode(int nIndex);
	BOOL GetRFilesEncode(CString strLocalName);
	CString GetRFilesPathName(int nIndex);
	CString GetRFilesPathName(CString strLocalName);
	int GetRFilesCount();
	CString GetRFilesName(int nIndex);
	BOOL IsRFileExist(CString sName);
	BOOL DelKeyWord(CString sFileName,CString sSectionName,CString sValue);
	void AddKeyWord(CString sFileName, CString sSectionName, CString sValue);
	CString GetKeyWordSectionName(int nIndex);
	CString GetKeyWordFileName(int nIndex);
	CString GetKeyWordValue(int nIndex);
	int GetKeyWordCount();
	BOOL IsKeyWordExist(CString sFileName, CString sSectionName, CString sValue);
	BOOL SetRegistryValue(HKEY hOpenKey,LPCTSTR szKey,LPCTSTR szValue,LPCTSTR szData);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperConfigApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CSuperConfigApp)
	afx_msg void OnAppAbout();
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CSuperConfigApp theApp;
extern BOOL g_bSyncHigh;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPERCONFIG_H__E585CAB4_BE5E_43F2_B4C6_AFEB05AC9183__INCLUDED_)
